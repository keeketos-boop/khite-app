import { useState } from 'react';
import { Search, Plus, Eye, CheckCircle, XCircle, Truck, Clock, Package, RefreshCw } from 'lucide-react';
import { ORDERS } from '../data/seed';
import type { Order, OrderStatus } from '../types';

const SM: Record<OrderStatus, { label: string; cls: string }> = {
  pending:    { label: 'بانتظار القبول', cls: 'badge-warn' },
  accepted:   { label: 'مقبول',           cls: 'badge-info' },
  in_transit: { label: 'في الطريق',       cls: 'badge-info' },
  delivered:  { label: 'تم التوصيل',      cls: 'badge-ok' },
  cancelled:  { label: 'ملغي',            cls: 'badge-err' },
};
const PM: Record<string, string> = { cash: 'نقدي', card: 'بطاقة بنكية', prepaid: 'بطاقة مسبقة' };

const TABS = [
  { v: 'all', l: 'الكل' }, { v: 'pending', l: 'بانتظار' }, { v: 'in_transit', l: 'في الطريق' },
  { v: 'delivered', l: 'تم التوصيل' }, { v: 'cancelled', l: 'ملغي' },
];

export default function Orders() {
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [sel, setSel] = useState<Order | null>(null);
  const [orders, setOrders] = useState<Order[]>(ORDERS);

  const list = orders.filter(o => {
    const ms = filter === 'all' || o.status === filter;
    const mq = !search || o.customer_name.includes(search) || o.id.includes(search);
    return ms && mq;
  });

  const accept = (id: string) => setOrders(p => p.map(o => o.id === id ? { ...o, status: 'accepted' } : o));
  const cancel = (id: string) => setOrders(p => p.map(o => o.id === id ? { ...o, status: 'cancelled' } : o));

  return (
    <div className="space-y-5 page-in">

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { l: 'إجمالي اليوم', v: orders.length.toString(), icon: Package, c: 'text-gold-400' },
          { l: 'بانتظار', v: orders.filter(o => o.status === 'pending').length.toString(), icon: Clock, c: 'text-yellow-400' },
          { l: 'في الطريق', v: orders.filter(o => o.status === 'in_transit').length.toString(), icon: Truck, c: 'text-blue-400' },
          { l: 'تم التوصيل', v: orders.filter(o => o.status === 'delivered').length.toString(), icon: CheckCircle, c: 'text-emerald-400' },
        ].map((s, i) => { const I = s.icon; return (
          <div key={i} className="card rounded-xl p-4 border border-gold-900/15">
            <I size={17} className={s.c + ' mb-2'} />
            <p className="text-white font-bold text-xl">{s.v}</p>
            <p className="text-dk-400 text-xs mt-0.5">{s.l}</p>
          </div>
        ); })}
      </div>

      {/* Controls */}
      <div className="glass rounded-2xl border border-gold-900/15 p-4 space-y-3">
        <div className="flex flex-wrap gap-3 items-center justify-between">
          <div className="flex items-center gap-2 glass rounded-xl px-3 py-2 border border-gold-900/15 flex-1 max-w-xs">
            <Search size={13} className="text-dk-400 shrink-0" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="بحث..." className="inp text-sm" />
          </div>
          <div className="flex gap-2">
            <button onClick={() => setOrders(ORDERS)} className="flex items-center gap-1.5 px-3 py-2 glass rounded-xl border border-gold-900/15 text-dk-300 hover:text-gold-400 text-sm">
              <RefreshCw size={13} /> تحديث
            </button>
            <button className="btn-gold px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-1.5">
              <Plus size={13} /> طلب جديد
            </button>
          </div>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-0.5">
          {TABS.map(t => (
            <button key={t.v} onClick={() => setFilter(t.v)}
              className={`shrink-0 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${filter === t.v ? 'btn-gold' : 'glass border border-gold-900/15 text-dk-300 hover:text-gold-400'}`}>
              {t.l}
            </button>
          ))}
        </div>
      </div>

      <div className="flex gap-5">
        {/* Table */}
        <div className={`${sel ? 'hidden lg:block lg:flex-1' : 'w-full'}`}>
          <div className="glass rounded-2xl border border-gold-900/15 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[620px]">
                <thead>
                  <tr className="border-b border-gold-900/15">
                    {['رقم الطلب','العميل','المتجر','المبلغ','الدفع','الحالة','الإجراء'].map(h => (
                      <th key={h} className="text-right py-3 px-4 text-dk-400 text-xs font-semibold">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {list.map(o => {
                    const s = SM[o.status];
                    return (
                      <tr key={o.id} onClick={() => setSel(sel?.id === o.id ? null : o)}
                        className={`trow border-b border-gold-900/8 cursor-pointer transition-colors ${sel?.id === o.id ? 'bg-gold-500/5' : ''}`}>
                        <td className="py-3 px-4 text-gold-400 text-xs font-mono font-bold">{o.id}</td>
                        <td className="py-3 px-4 text-white text-sm">{o.customer_name}</td>
                        <td className="py-3 px-4 text-dk-300 text-xs">{o.store_name}</td>
                        <td className="py-3 px-4 text-gold-300 font-bold text-sm">{o.total_amount} د.ل</td>
                        <td className="py-3 px-4 text-dk-300 text-xs">{PM[o.payment_method]}</td>
                        <td className="py-3 px-4"><span className={`${s.cls} px-2 py-0.5 rounded-full text-[10px] font-semibold`}>{s.label}</span></td>
                        <td className="py-3 px-4">
                          <div className="flex gap-1">
                            <button className="w-7 h-7 glass rounded-lg border border-gold-900/15 flex items-center justify-center text-gold-400 hover:bg-gold-500/10 transition-all" onClick={e => { e.stopPropagation(); setSel(o); }}>
                              <Eye size={12} />
                            </button>
                            {o.status === 'pending' && <>
                              <button onClick={e => { e.stopPropagation(); accept(o.id); }} className="w-7 h-7 glass rounded-lg border border-emerald-500/20 flex items-center justify-center text-emerald-400 hover:bg-emerald-500/10 transition-all">
                                <CheckCircle size={12} />
                              </button>
                              <button onClick={e => { e.stopPropagation(); cancel(o.id); }} className="w-7 h-7 glass rounded-lg border border-red-500/20 flex items-center justify-center text-red-400 hover:bg-red-500/10 transition-all">
                                <XCircle size={12} />
                              </button>
                            </>}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            {list.length === 0 && (
              <div className="text-center py-12 text-dk-500">
                <Package size={36} className="mx-auto mb-3 opacity-30" />
                <p className="text-sm">لا توجد طلبات مطابقة</p>
              </div>
            )}
          </div>
        </div>

        {/* Detail panel */}
        {sel && (
          <div className="w-full lg:w-72 shrink-0 animate-slide-right">
            <div className="glass rounded-2xl border border-gold-900/15 p-5 sticky top-20">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white font-bold text-sm">تفاصيل الطلب</h3>
                <button onClick={() => setSel(null)} className="text-dk-500 hover:text-white"><XCircle size={16} /></button>
              </div>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-gold-400 font-mono font-bold">{sel.id}</span>
                  <span className={`${SM[sel.status].cls} px-2 py-0.5 rounded-full text-[10px] font-semibold`}>{SM[sel.status].label}</span>
                </div>
                {[
                  ['العميل', sel.customer_name], ['المتجر', sel.store_name],
                  ['المبلغ', `${sel.total_amount} د.ل`], ['الدفع', PM[sel.payment_method]],
                  ['المنطقة', sel.area], ...(sel.driver_name ? [['السائق', sel.driver_name]] : []),
                ].map(([k, v]) => (
                  <div key={k} className="flex justify-between py-1.5 border-b border-gold-900/10 text-sm">
                    <span className="text-dk-400">{k}</span>
                    <span className="text-white font-medium">{v}</span>
                  </div>
                ))}
                {sel.status === 'pending' && (
                  <div className="flex gap-2 mt-3">
                    <button onClick={() => accept(sel.id)} className="flex-1 btn-gold py-2 rounded-xl text-xs font-bold">قبول</button>
                    <button onClick={() => cancel(sel.id)} className="flex-1 py-2 rounded-xl text-xs font-bold glass border border-red-500/25 text-red-400 hover:bg-red-500/10">رفض</button>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
