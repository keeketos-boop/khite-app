import { useState } from 'react';
import { Share2, Copy, Users, TrendingUp, Gift, Check, Link } from 'lucide-react';

const REF_LIST = [
  { name: 'محمد الصالح', code: 'KHITE-MS01', joined: 3, earned: 45, date: '20 يونيو 2025' },
  { name: 'نورا العبيدي', code: 'KHITE-NE02', joined: 7, earned: 105, date: '15 يونيو 2025' },
  { name: 'علي التهامي', code: 'KHITE-AT03', joined: 1, earned: 15, date: '28 يونيو 2025' },
  { name: 'رنا الفرجاني', code: 'KHITE-RF04', joined: 12, earned: 180, date: '10 يونيو 2025' },
];

const MY_CODE = 'KHITE-ADMIN01';

export default function Referrals() {
  const [copied, setCopied] = useState(false);

  const copy = () => { setCopied(true); setTimeout(() => setCopied(false), 2000); };

  return (
    <div className="space-y-5 page-in">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { l: 'إجمالي الإحالات', v: '23', icon: Users, c: 'text-gold-400' },
          { l: 'الأرباح', v: '345 د.ل', icon: TrendingUp, c: 'text-emerald-400' },
          { l: 'روابط نشطة', v: '4', icon: Link, c: 'text-blue-400' },
          { l: 'مكافآت معلقة', v: '60 د.ل', icon: Gift, c: 'text-purple-400' },
        ].map((s, i) => { const I = s.icon; return (
          <div key={i} className="card rounded-xl p-4"><I size={17} className={s.c + ' mb-2'} /><p className="text-white font-bold text-xl">{s.v}</p><p className="text-dk-400 text-xs mt-0.5">{s.l}</p></div>
        ); })}
      </div>

      <div className="glass rounded-2xl border border-gold-500/18 p-6">
        <h3 className="text-white font-bold mb-1">كود الإحالة الخاص بك</h3>
        <p className="text-dk-400 text-xs mb-5">شارك الكود واكسب 15 د.ل لكل شخص ينضم عبرك</p>
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex-1 min-w-48 glass rounded-xl px-4 py-3 border border-gold-500/25">
            <span className="text-gold-400 font-mono font-black text-xl tracking-widest">{MY_CODE}</span>
          </div>
          <button onClick={copy} className={`flex items-center gap-2 px-4 py-3 rounded-xl font-bold text-sm transition-all shrink-0 ${copied ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/25' : 'btn-gold'}`}>
            {copied ? <><Check size={15} /> تم!</> : <><Copy size={15} /> نسخ</>}
          </button>
          <button className="flex items-center gap-2 px-4 py-3 glass rounded-xl border border-gold-900/15 text-gold-400 hover:bg-gold-500/10 font-bold text-sm transition-all shrink-0">
            <Share2 size={15} /> مشاركة
          </button>
        </div>
        <div className="flex gap-2 mt-3 flex-wrap">
          {['واتساب','تيليغرام','فيسبوك','نسخ الرابط'].map(ch => (
            <button key={ch} className="px-3 py-1.5 glass rounded-lg border border-gold-900/15 text-dk-300 hover:text-gold-400 text-xs transition-all">{ch}</button>
          ))}
        </div>
      </div>

      <div className="glass rounded-2xl border border-gold-900/15 p-5">
        <h3 className="text-white font-bold mb-4">كيف يعمل البرنامج؟</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[
            { n: '1', t: 'شارك كودك', d: 'أرسل كود الإحالة لأصدقائك عبر أي وسيلة تواصل.' },
            { n: '2', t: 'ينضمون', d: 'عند تسجيلهم باستخدام كودك يُحسب لك الإحالة تلقائياً.' },
            { n: '3', t: 'تربح', d: 'احصل على 15 د.ل لكل شخص ينضم ويُكمل أول طلب.' },
          ].map(s => (
            <div key={s.n} className="glass rounded-xl border border-gold-900/15 p-4">
              <div className="w-9 h-9 rounded-full btn-gold flex items-center justify-center font-black text-black mb-3">{s.n}</div>
              <h4 className="text-white font-bold text-sm mb-1">{s.t}</h4>
              <p className="text-dk-300 text-xs leading-relaxed">{s.d}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="glass rounded-2xl border border-gold-900/15 overflow-hidden">
        <div className="p-4 border-b border-gold-900/15"><h3 className="text-white font-bold">سجل الإحالات</h3></div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[480px]">
            <thead><tr className="border-b border-gold-900/15">
              {['المُحيل','الكود','المُنضمون','المكافأة','التاريخ'].map(h => (
                <th key={h} className="text-right py-3 px-4 text-dk-400 text-xs font-semibold">{h}</th>
              ))}
            </tr></thead>
            <tbody>
              {REF_LIST.map((r, i) => (
                <tr key={i} className="trow border-b border-gold-900/8">
                  <td className="py-3 px-4 text-white text-sm">{r.name}</td>
                  <td className="py-3 px-4 text-gold-400 font-mono font-bold text-xs">{r.code}</td>
                  <td className="py-3 px-4 text-dk-300 text-xs">{r.joined} أشخاص</td>
                  <td className="py-3 px-4 text-gold-300 font-bold text-sm">{r.earned} د.ل</td>
                  <td className="py-3 px-4 text-dk-400 text-xs">{r.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
