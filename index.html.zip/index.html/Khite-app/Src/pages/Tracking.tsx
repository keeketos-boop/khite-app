import { useState } from 'react';
import { MapPin, Navigation, Truck, Phone, Star, Clock, CheckCircle } from 'lucide-react';
import { DRIVERS, ORDERS } from '../data/seed';

const active = ORDERS.filter(o => o.status === 'in_transit');

export default function Tracking() {
  const [selId, setSelId] = useState(DRIVERS[0].id);
  const driver = DRIVERS.find(d => d.id === selId)!;

  const positions = [
    { top: '18%', left: '22%' }, { top: '42%', left: '55%' },
    { top: '62%', left: '28%' }, { top: '30%', left: '70%' },
    { top: '75%', left: '65%' },
  ];

  return (
    <div className="space-y-5 page-in">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { l: 'نشطون', v: DRIVERS.filter(d => d.status === 'active').length, c: 'text-emerald-400', icon: CheckCircle },
          { l: 'مشغولون', v: DRIVERS.filter(d => d.status === 'busy').length, c: 'text-yellow-400', icon: Truck },
          { l: 'غير متاحين', v: DRIVERS.filter(d => d.status === 'offline').length, c: 'text-red-400', icon: Clock },
          { l: 'في الطريق', v: active.length, c: 'text-gold-400', icon: MapPin },
        ].map((s, i) => { const I = s.icon; return (
          <div key={i} className="card rounded-xl p-4"><I size={17} className={s.c + ' mb-2'} /><p className="text-white font-bold text-xl">{s.v}</p><p className="text-dk-400 text-xs mt-0.5">{s.l}</p></div>
        ); })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Map */}
        <div className="lg:col-span-2 glass rounded-2xl border border-gold-900/15 overflow-hidden" style={{ height: 480 }}>
          <div className="relative w-full h-full map-grid" style={{ background: 'linear-gradient(135deg,#0b0905 0%,#161008 50%,#0b0905 100%)' }}>

            {/* Header */}
            <div className="absolute top-4 right-4 flex items-center gap-2 glass px-3 py-1.5 rounded-xl border border-gold-900/15">
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-dot-pulse" />
              <span className="text-white text-xs font-semibold">تتبع مباشر — غات، ليبيا</span>
            </div>

            {/* Driver pins */}
            {DRIVERS.filter(d => d.status !== 'offline').map((d, i) => (
              <div key={d.id} className="absolute cursor-pointer" style={{ top: positions[i]?.top ?? '50%', left: positions[i]?.left ?? '50%' }}
                onClick={() => setSelId(d.id)}>
                <div className={`relative w-11 h-11 rounded-full flex items-center justify-center font-bold text-sm border-2 transition-all
                  ${d.status === 'active' ? 'bg-emerald-500/20 border-emerald-400 text-emerald-200' : 'bg-yellow-500/20 border-yellow-400 text-yellow-200'}
                  ${selId === d.id ? 'scale-125 shadow-[0_0_20px_rgba(245,158,11,0.6)]' : 'hover:scale-110'}`}>
                  {d.avatar_letter}
                  {d.status === 'active' && <div className="absolute inset-0 rounded-full border-2 border-emerald-400 animate-ping opacity-25" />}
                </div>
                {selId === d.id && (
                  <div className="absolute top-full mt-1 right-1/2 translate-x-1/2 glass px-2 py-0.5 rounded-lg border border-gold-900/25 whitespace-nowrap text-[10px] text-gold-300">
                    {d.name}
                  </div>
                )}
              </div>
            ))}

            {/* Order pins */}
            {active.map((o, i) => (
              <div key={o.id} className="absolute" style={{ top: `${50 + i * 13}%`, left: `${35 + i * 18}%` }}>
                <MapPin size={18} className="text-gold-400 drop-shadow" />
              </div>
            ))}

            {/* Compass */}
            <div className="absolute bottom-4 left-4 w-10 h-10 glass rounded-full border border-gold-900/20 flex items-center justify-center">
              <Navigation size={16} className="text-gold-400 animate-spin-slow" />
            </div>

            {/* Zoom */}
            <div className="absolute bottom-4 right-4 flex flex-col gap-1">
              {['+','−'].map(z => (
                <button key={z} className="w-8 h-8 glass border border-gold-900/20 rounded-lg text-gold-400 hover:bg-gold-500/10 transition-all font-bold text-sm flex items-center justify-center">{z}</button>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-3">
          <div className="glass rounded-2xl border border-gold-900/15 p-4">
            <h3 className="text-white font-bold text-sm mb-3">السائقون</h3>
            <div className="space-y-2">
              {DRIVERS.map(d => (
                <button key={d.id} onClick={() => setSelId(d.id)}
                  className={`w-full flex items-center gap-3 p-2.5 rounded-xl transition-all ${selId === d.id ? 'bg-gold-500/10 border border-gold-500/25' : 'glass border border-gold-900/15 hover:border-gold-900/35'}`}>
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-gold-600 to-gold-800 flex items-center justify-center text-black font-bold text-sm shrink-0">
                    {d.avatar_letter}
                  </div>
                  <div className="flex-1 text-right min-w-0">
                    <p className="text-white text-xs font-semibold truncate">{d.name}</p>
                    <p className="text-dk-400 text-[10px]">{d.area}</p>
                  </div>
                  <div className={`w-2 h-2 rounded-full shrink-0 ${d.status === 'active' ? 'bg-emerald-400' : d.status === 'busy' ? 'bg-yellow-400' : 'bg-red-400'}`} />
                </button>
              ))}
            </div>
          </div>

          {driver && (
            <div className="glass rounded-2xl border border-gold-900/15 p-4 animate-fade-up">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-gold-500 to-gold-700 flex items-center justify-center text-black font-bold text-xl shrink-0">
                  {driver.avatar_letter}
                </div>
                <div>
                  <p className="text-white font-bold text-sm">{driver.name}</p>
                  <div className="flex items-center gap-1">
                    <Star size={11} className="text-gold-400 fill-gold-400" />
                    <span className="text-gold-400 text-xs font-bold">{driver.rating}</span>
                  </div>
                </div>
              </div>
              {[
                ['الهاتف', driver.phone], ['المنطقة', driver.area],
                ['الطلبات', `${driver.total_orders} طلب`],
                ['الحالة', driver.status === 'active' ? 'متاح' : driver.status === 'busy' ? 'مشغول' : 'غير متاح'],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between py-1.5 border-b border-gold-900/10 text-xs">
                  <span className="text-dk-400">{k}</span>
                  <span className="text-white font-medium">{v}</span>
                </div>
              ))}
              <button className="w-full btn-gold py-2 rounded-xl text-xs font-bold mt-3 flex items-center justify-center gap-2">
                <Phone size={13} /> اتصال
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
