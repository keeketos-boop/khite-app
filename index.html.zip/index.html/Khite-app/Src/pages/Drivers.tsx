import { useState } from 'react';
import { UserCheck, Plus, Phone, MapPin, Star, Package, Clock, Search, CheckCircle } from 'lucide-react';
import { DRIVERS } from '../data/seed';
import type { Driver } from '../types';

const SC = { active: { l: 'متاح', cls: 'badge-ok', dot: 'bg-emerald-400' }, busy: { l: 'مشغول', cls: 'badge-warn', dot: 'bg-yellow-400' }, offline: { l: 'غير متاح', cls: 'badge-err', dot: 'bg-red-400' } } as const;

export default function Drivers() {
  const [drivers, setDrivers] = useState<Driver[]>(DRIVERS);
  const [search, setSearch] = useState('');

  const list = drivers.filter(d => d.name.includes(search) || d.area.includes(search));

  const cycleStatus = (id: string) => setDrivers(p => p.map(d => {
    if (d.id !== id) return d;
    const next = d.status === 'active' ? 'busy' : d.status === 'busy' ? 'offline' : 'active';
    return { ...d, status: next };
  }));

  return (
    <div className="space-y-5 page-in">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { l: 'إجمالي', v: drivers.length, icon: UserCheck, c: 'text-gold-400' },
          { l: 'متاحون', v: drivers.filter(d => d.status === 'active').length, icon: CheckCircle, c: 'text-emerald-400' },
          { l: 'مشغولون', v: drivers.filter(d => d.status === 'busy').length, icon: Clock, c: 'text-yellow-400' },
          { l: 'إجمالي الطلبات', v: drivers.reduce((s, d) => s + d.total_orders, 0), icon: Package, c: 'text-blue-400' },
        ].map((s, i) => { const I = s.icon; return (
          <div key={i} className="card rounded-xl p-4"><I size={17} className={s.c + ' mb-2'} /><p className="text-white font-bold text-xl">{s.v}</p><p className="text-dk-400 text-xs mt-0.5">{s.l}</p></div>
        ); })}
      </div>

      <div className="flex flex-wrap gap-3 items-center justify-between glass rounded-xl border border-gold-900/15 p-4">
        <div className="flex items-center gap-2 glass rounded-xl px-3 py-2 border border-gold-900/15 flex-1 max-w-xs">
          <Search size={13} className="text-dk-400 shrink-0" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="بحث في السائقين..." className="inp text-sm" />
        </div>
        <button className="btn-gold px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-1.5">
          <Plus size={13} /> إضافة سائق
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {list.map(d => {
          const sc = SC[d.status];
          return (
            <div key={d.id} className="card rounded-2xl p-5">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <div className="w-14 h-14 rounded-full bg-gradient-to-br from-gold-500 to-gold-700 flex items-center justify-center text-black font-black text-xl">{d.avatar_letter}</div>
                    <div className={`absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full border-2 border-dk-950 ${sc.dot} animate-dot-pulse`} />
                  </div>
                  <div>
                    <h4 className="text-white font-bold text-sm">{d.name}</h4>
                    <span className={`${sc.cls} px-2 py-0.5 rounded-full text-[10px] font-semibold`}>{sc.l}</span>
                  </div>
                </div>
                <span className="text-dk-500 text-[10px] font-mono">{d.id}</span>
              </div>

              <div className="space-y-1.5 mb-4">
                <div className="flex items-center gap-2"><Phone size={12} className="text-gold-500" /><span className="text-dk-300 text-xs">{d.phone}</span></div>
                <div className="flex items-center gap-2"><MapPin size={12} className="text-gold-500" /><span className="text-dk-300 text-xs">{d.area}</span></div>
              </div>

              <div className="grid grid-cols-2 gap-2 mb-4">
                <div className="glass rounded-lg p-2.5 text-center border border-gold-900/15">
                  <p className="text-gold-400 font-bold">{d.total_orders}</p>
                  <p className="text-dk-500 text-[10px]">طلب مكتمل</p>
                </div>
                <div className="glass rounded-lg p-2.5 text-center border border-gold-900/15">
                  <div className="flex items-center justify-center gap-0.5">
                    <Star size={11} className="text-gold-400 fill-gold-400" />
                    <p className="text-gold-400 font-bold">{d.rating}</p>
                  </div>
                  <p className="text-dk-500 text-[10px]">التقييم</p>
                </div>
              </div>

              <div className="flex gap-2">
                <button className="flex-1 flex items-center justify-center gap-1.5 py-2 btn-gold rounded-xl text-xs font-bold">
                  <Phone size={12} /> اتصال
                </button>
                <button onClick={() => cycleStatus(d.id)} className="flex-1 flex items-center justify-center gap-1.5 py-2 glass rounded-xl border border-gold-900/15 text-gold-400 hover:bg-gold-500/10 text-xs transition-all">
                  <MapPin size={12} /> تغيير
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
