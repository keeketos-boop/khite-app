import { useState } from 'react';
import { Store, Plus, Search, Star, TrendingUp, Package, Eye, Edit, ToggleLeft, ToggleRight } from 'lucide-react';
import { STORES } from '../data/seed';
import type { Store as StoreType } from '../types';

export default function Stores() {
  const [search, setSearch] = useState('');
  const [stores, setStores] = useState<StoreType[]>(STORES);

  const toggle = (id: string) => setStores(p => p.map(s => s.id === id ? { ...s, status: s.status === 'active' ? 'inactive' : 'active' } : s));

  const list = stores.filter(s => s.name.includes(search) || s.owner_name.includes(search));

  return (
    <div className="space-y-5 page-in">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { l: 'إجمالي المتاجر', v: stores.length, icon: Store, c: 'text-gold-400' },
          { l: 'نشطة', v: stores.filter(s => s.status === 'active').length, icon: TrendingUp, c: 'text-emerald-400' },
          { l: 'إجمالي الطلبات', v: stores.reduce((s, st) => s + st.total_orders, 0), icon: Package, c: 'text-blue-400' },
          { l: 'إجمالي الإيرادات', v: stores.reduce((s, st) => s + st.total_revenue, 0).toLocaleString() + ' د.ل', icon: TrendingUp, c: 'text-gold-400' },
        ].map((s, i) => { const I = s.icon; return (
          <div key={i} className="card rounded-xl p-4"><I size={17} className={s.c + ' mb-2'} /><p className="text-white font-bold text-lg">{s.v}</p><p className="text-dk-400 text-xs mt-0.5">{s.l}</p></div>
        ); })}
      </div>

      <div className="flex flex-wrap gap-3 items-center justify-between glass rounded-xl border border-gold-900/15 p-4">
        <div className="flex items-center gap-2 glass rounded-xl px-3 py-2 border border-gold-900/15 flex-1 max-w-xs">
          <Search size={13} className="text-dk-400 shrink-0" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="بحث في المتاجر..." className="inp text-sm" />
        </div>
        <button className="btn-gold px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-1.5">
          <Plus size={13} /> إضافة متجر
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {list.map(s => (
          <div key={s.id} className="card rounded-2xl p-5">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-gold-500/10 border border-gold-900/20 flex items-center justify-center shrink-0">
                  <Store size={20} className="text-gold-400" />
                </div>
                <div>
                  <h4 className="text-white font-bold text-sm">{s.name}</h4>
                  <p className="text-dk-400 text-xs">{s.owner_name}</p>
                </div>
              </div>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${s.status === 'active' ? 'badge-ok' : 'badge-err'}`}>
                {s.status === 'active' ? 'نشط' : 'غير نشط'}
              </span>
            </div>

            <span className="badge-info px-2 py-0.5 rounded-full text-[10px] font-semibold">{s.category}</span>

            <div className="grid grid-cols-3 gap-2 my-4">
              {[
                [s.total_orders.toString(), 'طلب'],
                [s.total_revenue.toLocaleString(), 'د.ل'],
              ].map(([v, l]) => (
                <div key={l} className="text-center">
                  <p className="text-gold-400 font-bold text-sm">{v}</p>
                  <p className="text-dk-500 text-[10px]">{l}</p>
                </div>
              ))}
              <div className="text-center">
                <div className="flex items-center justify-center gap-0.5">
                  <Star size={11} className="text-gold-400 fill-gold-400" />
                  <p className="text-gold-400 font-bold text-sm">{s.rating}</p>
                </div>
                <p className="text-dk-500 text-[10px]">تقييم</p>
              </div>
            </div>

            <div className="flex gap-2">
              <button className="flex-1 flex items-center justify-center gap-1 py-1.5 glass rounded-lg border border-gold-900/15 text-gold-400 hover:bg-gold-500/10 text-xs transition-all">
                <Eye size={11} /> عرض
              </button>
              <button className="flex-1 flex items-center justify-center gap-1 py-1.5 glass rounded-lg border border-blue-900/15 text-blue-400 hover:bg-blue-500/10 text-xs transition-all">
                <Edit size={11} /> تعديل
              </button>
              <button onClick={() => toggle(s.id)} className="flex items-center justify-center gap-1 py-1.5 px-3 glass rounded-lg border border-gold-900/15 text-dk-400 hover:text-gold-400 text-xs transition-all">
                {s.status === 'active' ? <ToggleRight size={13} className="text-emerald-400" /> : <ToggleLeft size={13} />}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
