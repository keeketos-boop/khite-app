import { useState } from 'react';
import { Package, AlertTriangle, Plus, Search, TrendingDown, TrendingUp } from 'lucide-react';
import { INVENTORY } from '../data/seed';
import type { InventoryItem } from '../types';

const getStatus = (item: InventoryItem) =>
  item.stock === 0 ? 'out' : item.stock < item.threshold ? 'low' : 'normal';

const StatusBadge = ({ s }: { s: string }) =>
  s === 'normal' ? <span className="badge-ok px-2 py-0.5 rounded-full text-[10px] font-semibold">طبيعي</span> :
  s === 'low'    ? <span className="badge-warn px-2 py-0.5 rounded-full text-[10px] font-semibold">منخفض</span> :
                   <span className="badge-err px-2 py-0.5 rounded-full text-[10px] font-semibold">نفد</span>;

export default function Inventory() {
  const [search, setSearch] = useState('');
  const [items, setItems] = useState<InventoryItem[]>(INVENTORY);

  const filtered = items.filter(i => i.name.includes(search) || i.category.includes(search));
  const out  = items.filter(i => getStatus(i) === 'out').length;
  const low  = items.filter(i => getStatus(i) === 'low').length;
  const good = items.filter(i => getStatus(i) === 'normal').length;

  return (
    <div className="space-y-5 page-in">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { l: 'إجمالي المنتجات', v: items.length, icon: Package, c: 'text-gold-400' },
          { l: 'مخزون طبيعي', v: good, icon: TrendingUp, c: 'text-emerald-400' },
          { l: 'مخزون منخفض', v: low, icon: TrendingDown, c: 'text-yellow-400' },
          { l: 'نفد المخزون', v: out, icon: AlertTriangle, c: 'text-red-400' },
        ].map((s, i) => { const I = s.icon; return (
          <div key={i} className="card rounded-xl p-4"><I size={17} className={s.c + ' mb-2'} /><p className="text-white font-bold text-xl">{s.v}</p><p className="text-dk-400 text-xs mt-0.5">{s.l}</p></div>
        ); })}
      </div>

      {(out > 0 || low > 0) && (
        <div className="glass rounded-xl border border-yellow-500/25 p-4 flex items-center gap-3">
          <AlertTriangle size={17} className="text-yellow-400 shrink-0" />
          <p className="text-dk-200 text-sm flex-1">
            {out > 0 && `${out} منتجات نفدت. `}{low > 0 && `${low} منتجات بمخزون منخفض.`} يرجى إعادة الطلب.
          </p>
          <button className="btn-gold px-3 py-1.5 rounded-lg text-xs font-bold shrink-0">إعادة الطلب</button>
        </div>
      )}

      <div className="flex flex-wrap gap-3 items-center justify-between glass rounded-xl border border-gold-900/15 p-4">
        <div className="flex items-center gap-2 glass rounded-xl px-3 py-2 border border-gold-900/15 flex-1 max-w-xs">
          <Search size={13} className="text-dk-400 shrink-0" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="بحث في المخزون..." className="inp text-sm" />
        </div>
        <button className="btn-gold px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-1.5">
          <Plus size={13} /> إضافة منتج
        </button>
      </div>

      <div className="glass rounded-2xl border border-gold-900/15 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[600px]">
            <thead>
              <tr className="border-b border-gold-900/15">
                {['المنتج','التصنيف','المخزون','الحد الأدنى','السعر','المستوى','الحالة','إجراء'].map(h => (
                  <th key={h} className="text-right py-3 px-4 text-dk-400 text-xs font-semibold">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(item => {
                const st = getStatus(item);
                return (
                  <tr key={item.id} className="trow border-b border-gold-900/8">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg glass border border-gold-900/15 flex items-center justify-center shrink-0">
                          <Package size={13} className="text-gold-500" />
                        </div>
                        <span className="text-white text-sm">{item.name}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-dk-300 text-xs">{item.category}</td>
                    <td className="py-3 px-4">
                      <span className={`font-bold text-sm ${st === 'normal' ? 'text-emerald-400' : st === 'low' ? 'text-yellow-400' : 'text-red-400'}`}>{item.stock}</span>
                    </td>
                    <td className="py-3 px-4 text-dk-400 text-xs">{item.threshold}</td>
                    <td className="py-3 px-4 text-gold-300 text-xs font-bold">{item.price} د.ل</td>
                    <td className="py-3 px-4 w-28">
                      <div className="w-full bg-dk-800 rounded-full h-1.5">
                        <div className={`h-1.5 rounded-full ${st === 'out' ? 'bg-red-500' : st === 'low' ? 'bg-yellow-500' : 'prog-bar'}`}
                          style={{ width: `${Math.min((item.stock / (item.threshold * 5)) * 100, 100)}%` }} />
                      </div>
                    </td>
                    <td className="py-3 px-4"><StatusBadge s={st} /></td>
                    <td className="py-3 px-4">
                      <button onClick={() => setItems(p => p.map(i => i.id === item.id ? { ...i, stock: i.stock + 20 } : i))}
                        className="text-xs text-gold-400 hover:text-gold-300 transition-colors">+20</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
