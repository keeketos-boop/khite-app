import {
  ShoppingCart, Truck, Store, TrendingUp, Users, Zap,
  ArrowUpRight, ArrowDownRight, Package, CreditCard, Clock, Star
} from 'lucide-react';
import type { Page } from '../types';
import { ORDERS, CHART_WEEKLY, CHART_LABELS } from '../data/seed';

const STATS = [
  { label: 'الطلبات اليوم', value: '247', change: '+18%', up: true, icon: ShoppingCart, cls: 'text-gold-400' },
  { label: 'التوصيل الجاري', value: '34', change: '+6%', up: true, icon: Truck, cls: 'text-blue-400' },
  { label: 'المتاجر النشطة', value: '38', change: '+2', up: true, icon: Store, cls: 'text-emerald-400' },
  { label: 'الإيرادات اليوم', value: '4,820 د.ل', change: '+22%', up: true, icon: TrendingUp, cls: 'text-gold-400' },
  { label: 'العملاء المسجلون', value: '1,247', change: '+45', up: true, icon: Users, cls: 'text-purple-400' },
  { label: 'السائقون المتاحون', value: '5/12', change: '-1', up: false, icon: Zap, cls: 'text-orange-400' },
];

const STATUS_MAP: Record<string, { label: string; cls: string }> = {
  pending:    { label: 'بانتظار', cls: 'badge-warn' },
  accepted:   { label: 'مقبول',   cls: 'badge-info' },
  in_transit: { label: 'في الطريق', cls: 'badge-info' },
  delivered:  { label: 'تم',       cls: 'badge-ok' },
  cancelled:  { label: 'ملغي',     cls: 'badge-err' },
};

const MAX = Math.max(...CHART_WEEKLY);

export default function Dashboard({ onNav }: { onNav: (p: Page) => void }) {
  return (
    <div className="space-y-5 page-in">

      {/* Banner */}
      <div className="relative overflow-hidden rounded-2xl p-5 lg:p-6 border border-gold-900/25"
        style={{ background: 'linear-gradient(135deg,rgba(180,83,9,.18) 0%,rgba(10,8,4,.9) 60%,rgba(120,53,15,.1) 100%)' }}>
        <div className="relative z-10 flex flex-wrap gap-4 items-start justify-between">
          <div>
            <h2 className="text-xl lg:text-2xl font-black text-white mb-1">
              مرحباً بك في <span className="gold-text">خيط</span>
            </h2>
            <p className="text-dk-300 text-sm">أول منصة دلفري مؤتمتة بالذكاء الاصطناعي في ليبيا — من غات</p>
            <div className="flex flex-wrap gap-2 mt-3">
              <span className="badge-ok px-3 py-1 rounded-full text-xs font-semibold">منصة نشطة</span>
              <span className="badge-info px-3 py-1 rounded-full text-xs font-semibold">v2.4.1</span>
              <span className="text-dk-500 text-xs self-center">9 يوليو 2025</span>
            </div>
          </div>
          <div className="flex gap-2 flex-wrap">
            <button onClick={() => onNav('orders')} className="btn-gold px-4 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2">
              <ShoppingCart size={14} /> الطلبات
            </button>
            <button onClick={() => onNav('ai-assistant')} className="px-4 py-2.5 rounded-xl text-sm font-semibold glass border border-gold-500/25 text-gold-400 hover:bg-gold-500/10 transition-all flex items-center gap-2">
              <Zap size={14} /> الذكاء الاصطناعي
            </button>
          </div>
        </div>
        <div className="absolute -left-8 -bottom-8 w-40 h-40 rounded-full bg-gold-600/5 blur-3xl pointer-events-none" />
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-3">
        {STATS.map((s, i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="card rounded-xl p-4 cursor-pointer">
              <Icon size={17} className={s.cls + ' mb-3'} />
              <p className="text-white font-bold text-lg leading-none">{s.value}</p>
              <p className="text-dk-400 text-[11px] mt-1 leading-snug">{s.label}</p>
              <p className={`text-[11px] font-semibold mt-1.5 flex items-center gap-0.5 ${s.up ? 'text-emerald-400' : 'text-red-400'}`}>
                {s.up ? <ArrowUpRight size={11} /> : <ArrowDownRight size={11} />}{s.change}
              </p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Chart */}
        <div className="lg:col-span-2 glass rounded-2xl border border-gold-900/15 p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-white font-bold">الطلبات الأسبوعية</h3>
              <p className="text-dk-500 text-xs mt-0.5">آخر 7 أيام</p>
            </div>
            <span className="badge-warn px-2.5 py-1 rounded-full text-xs font-semibold">إجمالي 610</span>
          </div>
          <div className="flex items-end gap-2 h-36">
            {CHART_WEEKLY.map((v, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-1.5">
                <span className="text-gold-400 text-[10px] font-bold">{v}</span>
                <div className="w-full rounded-t-md prog-bar chart-bar" style={{ height: `${(v / MAX) * 110}px`, animationDelay: `${i * 0.08}s` }} />
                <span className="text-[10px] text-dk-500">{CHART_LABELS[i]}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Quick access */}
        <div className="glass rounded-2xl border border-gold-900/15 p-5">
          <h3 className="text-white font-bold mb-4">وصول سريع</h3>
          <div className="space-y-2">
            {[
              { label: 'مخزون منخفض', sub: '3 منتجات', icon: Package, p: 'inventory' as Page, c: 'text-red-400' },
              { label: 'مدفوعات معلقة', sub: '5 معاملات', icon: CreditCard, p: 'payments' as Page, c: 'text-blue-400' },
              { label: 'طلبات متأخرة', sub: '2 طلبات', icon: Clock, p: 'orders' as Page, c: 'text-orange-400' },
              { label: 'تقييمات جديدة', sub: '12 تقييم', icon: Star, p: 'ratings' as Page, c: 'text-gold-400' },
            ].map((q, i) => {
              const Icon = q.icon;
              return (
                <button key={i} onClick={() => onNav(q.p)}
                  className="w-full flex items-center gap-3 px-3 py-2.5 glass rounded-xl border border-gold-900/15 hover:border-gold-900/35 transition-all group">
                  <Icon size={16} className={q.c} />
                  <div className="flex-1 text-right">
                    <p className="text-white text-xs font-semibold">{q.label}</p>
                    <p className="text-dk-400 text-[10px]">{q.sub}</p>
                  </div>
                  <ArrowUpRight size={13} className="text-dk-500 group-hover:text-gold-400 transition-colors" />
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Recent orders */}
      <div className="glass rounded-2xl border border-gold-900/15 p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-white font-bold">آخر الطلبات</h3>
          <button onClick={() => onNav('orders')} className="text-gold-400 text-xs hover:text-gold-300 flex items-center gap-1">
            عرض الكل <ArrowUpRight size={13} />
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[500px]">
            <thead>
              <tr className="border-b border-gold-900/15">
                {['رقم الطلب', 'العميل', 'المبلغ', 'الحالة', 'المنطقة'].map(h => (
                  <th key={h} className="text-right py-2 px-3 text-dk-400 text-xs font-semibold">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {ORDERS.slice(0, 5).map(o => {
                const s = STATUS_MAP[o.status];
                return (
                  <tr key={o.id} className="trow border-b border-gold-900/8 cursor-pointer" onClick={() => onNav('orders')}>
                    <td className="py-2.5 px-3 text-gold-400 text-xs font-mono font-bold">{o.id}</td>
                    <td className="py-2.5 px-3 text-white text-sm">{o.customer_name}</td>
                    <td className="py-2.5 px-3 text-gold-300 text-sm font-bold">{o.total_amount} د.ل</td>
                    <td className="py-2.5 px-3"><span className={`${s.cls} px-2 py-0.5 rounded-full text-[10px] font-semibold`}>{s.label}</span></td>
                    <td className="py-2.5 px-3 text-dk-400 text-xs">{o.area}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
