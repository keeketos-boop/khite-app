import { useState, useRef, useEffect } from 'react';
import { Bot, Send, Zap, Store, UserCheck, Package, TrendingUp, Mic, RefreshCw } from 'lucide-react';

interface Msg { role: 'user' | 'bot'; text: string; time: string; }

const QUICK = [
  { l: 'تسجيل متجر جديد', icon: Store, q: 'أريد تسجيل متجر جديد في منصة خيط' },
  { l: 'إضافة سائق', icon: UserCheck, q: 'كيف أضيف سائق توصيل جديد؟' },
  { l: 'تحليل المخزون', icon: Package, q: 'أعطني تقريراً عن حالة المخزون الحالية' },
  { l: 'تقرير الأداء', icon: TrendingUp, q: 'ما هو أداء المنصة هذا الأسبوع؟' },
];

const BOT_REPLIES = [
  'بناءً على تحليل البيانات، إجمالي الطلبات هذا الأسبوع 247 طلباً بزيادة 18% عن الأسبوع الماضي. الإيرادات وصلت 4,820 د.ل.',
  'تم تسجيل المتجر الجديد بنجاح! الرقم: STR-006. سيكون نشطاً خلال 5 دقائق بعد التحقق التلقائي.',
  'أنصح بتوفير سائقين إضافيين يوم الجمعة والسبت. البيانات تُظهر زيادة 35% في الطلبات آخر يومي الأسبوع.',
  'تحليل المخزون: 3 منتجات نفدت (سكر أبيض، أرز بسمتي)، 2 منتجات بمخزون منخفض. يُنصح بإعادة الطلب الآن.',
  'تم إرسال تنبيه المخزون المنخفض لمتجر النور. سيصلهم إشعار تلقائي الآن.',
  'يمكنني مساعدتك بـ: تسجيل المتاجر والسائقين تلقائياً، تحليل الطلبات والإيرادات، وإدارة المخزون الذكي.',
];

const now = () => new Date().toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' });

const INIT: Msg[] = [{
  role: 'bot',
  text: 'مرحباً! أنا مساعد خيط الذكي.\n\nيمكنني مساعدتك في:\n• تسجيل المتاجر والسائقين تلقائياً\n• تحليل بيانات الطلبات والإيرادات\n• إدارة المخزون الذكي\n• توصيات لتحسين الأداء\n\nكيف يمكنني مساعدتك؟',
  time: now(),
}];

export default function AIAssistant() {
  const [msgs, setMsgs] = useState<Msg[]>(INIT);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [msgs]);

  const send = (text?: string) => {
    const q = text ?? input.trim();
    if (!q || loading) return;
    setMsgs(p => [...p, { role: 'user', text: q, time: now() }]);
    setInput('');
    setLoading(true);
    setTimeout(() => {
      setMsgs(p => [...p, { role: 'bot', text: BOT_REPLIES[Math.floor(Math.random() * BOT_REPLIES.length)], time: now() }]);
      setLoading(false);
    }, 1100 + Math.random() * 600);
  };

  return (
    <div className="space-y-5 page-in">

      <div className="glass rounded-2xl border border-gold-500/18 p-5 flex items-center gap-4">
        <div className="w-14 h-14 rounded-2xl btn-gold flex items-center justify-center animate-pulse-gold shrink-0">
          <Bot size={28} className="text-black" />
        </div>
        <div>
          <h2 className="text-white font-black text-xl">مساعد خيط الذكي</h2>
          <p className="text-dk-300 text-sm mt-0.5">تسجيل فوري وتحليل ذكي مدعوم بالذكاء الاصطناعي</p>
          <div className="flex items-center gap-2 mt-1.5">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-dot-pulse" />
            <span className="text-emerald-400 text-xs font-semibold">جاهز</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {QUICK.map((q, i) => { const I = q.icon; return (
          <button key={i} onClick={() => send(q.q)} className="card rounded-xl p-4 text-right group hover:border-gold-500/25">
            <I size={19} className="text-gold-400 mb-2" />
            <p className="text-white text-sm font-semibold">{q.l}</p>
          </button>
        ); })}
      </div>

      <div className="glass rounded-2xl border border-gold-900/15 overflow-hidden">
        <div className="h-72 overflow-y-auto p-4 space-y-4">
          {msgs.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-start' : 'justify-end'}`}>
              <div className="max-w-xs lg:max-w-md">
                {m.role === 'bot' && (
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-6 h-6 rounded-lg btn-gold flex items-center justify-center shrink-0"><Zap size={12} className="text-black" /></div>
                    <span className="text-gold-400 text-xs font-semibold">خيط AI</span>
                  </div>
                )}
                <div className={`rounded-2xl px-4 py-3 ${m.role === 'user' ? 'bg-dk-700 border border-gold-900/15 rounded-tl-sm' : 'glass border border-gold-500/18 rounded-tr-sm'}`}>
                  <p className="text-white text-sm leading-relaxed whitespace-pre-line">{m.text}</p>
                  <p className="text-dk-500 text-[10px] mt-1">{m.time}</p>
                </div>
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex justify-end">
              <div className="glass border border-gold-500/18 rounded-2xl rounded-tr-sm px-4 py-3">
                <div className="flex items-center gap-2">
                  <RefreshCw size={13} className="text-gold-400 animate-spin" />
                  <span className="text-dk-300 text-sm">جاري التحليل...</span>
                </div>
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        <div className="border-t border-gold-900/15 p-4">
          <div className="flex items-center gap-2">
            <div className="flex-1 flex items-center gap-2 glass rounded-xl px-3 py-2.5 border border-gold-900/18">
              <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()}
                placeholder="اكتب رسالتك..." className="inp text-sm flex-1" />
              <Mic size={14} className="text-dk-500 hover:text-gold-400 cursor-pointer transition-colors shrink-0" />
            </div>
            <button onClick={() => send()} disabled={!input.trim() || loading}
              className="w-10 h-10 btn-gold rounded-xl flex items-center justify-center disabled:opacity-40 shrink-0">
              <Send size={16} className="text-black" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
