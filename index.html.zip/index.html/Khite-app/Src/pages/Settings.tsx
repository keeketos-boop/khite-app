import { useState } from 'react';
import { Settings, Bell, Shield, Truck, Bot, Palette, ToggleLeft, ToggleRight } from 'lucide-react';

const SECTIONS = [
  { title: 'الإشعارات', icon: Bell, items: [
    { k: 'n_orders', l: 'إشعارات الطلبات الجديدة', v: true },
    { k: 'n_delivery', l: 'إشعارات التوصيل', v: true },
    { k: 'n_payments', l: 'إشعارات المدفوعات', v: true },
    { k: 'n_inv', l: 'تنبيهات المخزون المنخفض', v: true },
  ]},
  { title: 'الذكاء الاصطناعي', icon: Bot, items: [
    { k: 'ai_accept', l: 'قبول الطلبات تلقائياً', v: true },
    { k: 'ai_reg', l: 'تسجيل المتاجر تلقائياً', v: false },
    { k: 'ai_assign', l: 'توزيع الطلبات الذكي', v: true },
    { k: 'ai_analytics', l: 'التحليلات التلقائية', v: true },
  ]},
  { title: 'التوصيل', icon: Truck, items: [
    { k: 'gps', l: 'تتبع GPS مباشر', v: true },
    { k: 'cust_notif', l: 'إشعار العميل عند التوصيل', v: true },
    { k: 'auto_confirm', l: 'تأكيد استلام تلقائي', v: false },
  ]},
  { title: 'الأمان', icon: Shield, items: [
    { k: 'enc', l: 'تشفير البيانات', v: true },
    { k: '2fa', l: 'المصادقة الثنائية', v: false },
    { k: 'log', l: 'تسجيل النشاط', v: true },
  ]},
];

type TMap = Record<string, boolean>;

export default function SettingsPage() {
  const init: TMap = {};
  SECTIONS.forEach(s => s.items.forEach(i => { init[i.k] = i.v; }));
  const [t, setT] = useState<TMap>(init);
  const [saved, setSaved] = useState(false);

  const tog = (k: string) => setT(p => ({ ...p, [k]: !p[k] }));
  const save = () => { setSaved(true); setTimeout(() => setSaved(false), 2000); };

  return (
    <div className="space-y-5 page-in">

      {/* General */}
      <div className="glass rounded-2xl border border-gold-900/15 p-5">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-9 h-9 rounded-xl bg-gold-500/10 flex items-center justify-center shrink-0"><Settings size={17} className="text-gold-400" /></div>
          <div><h3 className="text-white font-bold">الإعدادات العامة</h3><p className="text-dk-400 text-xs">تخصيص منصة خيط</p></div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
          {[
            { l: 'اسم المنصة', v: 'خيط - Khite' }, { l: 'المدينة الرئيسية', v: 'غات، ليبيا' },
            { l: 'عملة المنصة', v: 'دينار ليبي (د.ل)' }, { l: 'لغة الواجهة', v: 'العربية' },
            { l: 'المنطقة الزمنية', v: 'Libya (UTC+2)' }, { l: 'بريد التواصل', v: 'admin@khite.ly' },
          ].map((f, i) => (
            <div key={i}>
              <label className="block text-dk-400 text-xs mb-1.5">{f.l}</label>
              <input defaultValue={f.v} className="w-full glass rounded-xl px-3 py-2.5 text-sm text-white border border-gold-900/15 focus:border-gold-500/35 outline-none transition-colors" />
            </div>
          ))}
        </div>
        <button onClick={save} className={`px-5 py-2.5 rounded-xl text-sm font-bold transition-all ${saved ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/25' : 'btn-gold'}`}>
          {saved ? 'تم الحفظ ✓' : 'حفظ الإعدادات'}
        </button>
      </div>

      {/* Toggle sections */}
      {SECTIONS.map(sec => {
        const I = sec.icon;
        return (
          <div key={sec.title} className="glass rounded-2xl border border-gold-900/15 p-5">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-xl bg-gold-500/10 flex items-center justify-center shrink-0"><I size={17} className="text-gold-400" /></div>
              <h3 className="text-white font-bold">{sec.title}</h3>
            </div>
            <div className="space-y-2">
              {sec.items.map(item => (
                <div key={item.k} className="flex items-center justify-between py-2 border-b border-gold-900/10">
                  <span className="text-dk-200 text-sm">{item.l}</span>
                  <button onClick={() => tog(item.k)}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${t[item.k] ? 'bg-gold-500/15 text-gold-400 border border-gold-500/25' : 'glass border border-gold-900/15 text-dk-400'}`}>
                    {t[item.k] ? <><ToggleRight size={15} /> مفعّل</> : <><ToggleLeft size={15} /> معطّل</>}
                  </button>
                </div>
              ))}
            </div>
          </div>
        );
      })}

      {/* Theme */}
      <div className="glass rounded-2xl border border-gold-900/15 p-5">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-9 h-9 rounded-xl bg-gold-500/10 flex items-center justify-center shrink-0"><Palette size={17} className="text-gold-400" /></div>
          <h3 className="text-white font-bold">المظهر</h3>
        </div>
        <p className="text-dk-400 text-xs mb-3">المنصة تعمل بالوضع الداكن الذهبي — خلفية صحراء غات</p>
        <div className="flex gap-3 flex-wrap">
          {[
            { n: 'ذهبي صحراوي', cs: ['#f59e0b','#0a0804'], active: true },
            { n: 'أزرق ليلي', cs: ['#3b82f6','#070d1a'], active: false },
            { n: 'أخضر زمرد', cs: ['#10b981','#040f0a'], active: false },
          ].map((th, i) => (
            <button key={i} className={`flex items-center gap-2 px-4 py-2.5 glass rounded-xl border text-sm transition-all ${th.active ? 'border-gold-500/35 text-gold-400' : 'border-gold-900/15 text-dk-300 hover:text-white'}`}>
              <div className="flex gap-1">{th.cs.map((c, j) => <div key={j} className="w-4 h-4 rounded-full border border-white/10" style={{ background: c }} />)}</div>
              {th.n}
              {th.active && <span className="badge-ok px-1.5 py-0.5 rounded-full text-[9px] font-semibold">نشط</span>}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
