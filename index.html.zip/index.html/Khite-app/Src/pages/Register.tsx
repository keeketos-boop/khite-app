import { useState } from 'react';
import { Zap, Store, UserCheck, User, Phone, MapPin, Mail, ChevronLeft, CheckCircle, Building } from 'lucide-react';

type Role = 'store' | 'driver' | 'customer';

const ROLES: { id: Role; l: string; desc: string; icon: React.ComponentType<{size?:number;className?:string}> }[] = [
  { id: 'store',    l: 'صاحب متجر', desc: 'سجّل متجرك وابدأ البيع عبر خيط',         icon: Store },
  { id: 'driver',   l: 'سائق توصيل', desc: 'انضم لفريق التوصيل واكسب دخلاً إضافياً', icon: UserCheck },
  { id: 'customer', l: 'عميل',       desc: 'اطلب من أفضل المتاجر في غات',            icon: User },
];

export default function Register() {
  const [role, setRole] = useState<Role | null>(null);
  const [step, setStep] = useState(1);
  const [done, setDone] = useState(false);
  const [regNum] = useState(() => Math.floor(Math.random() * 9000 + 1000));

  if (done) return (
    <div className="flex items-center justify-center min-h-80 page-in">
      <div className="glass rounded-2xl border border-gold-500/18 p-8 text-center max-w-sm">
        <div className="w-16 h-16 rounded-full btn-gold flex items-center justify-center mx-auto mb-4 animate-pulse-gold">
          <CheckCircle size={30} className="text-black" />
        </div>
        <h3 className="text-white font-black text-xl mb-2">تم التسجيل بنجاح!</h3>
        <p className="text-dk-300 text-sm mb-3">سيتم التحقق من بياناتك خلال 24 ساعة.</p>
        <p className="text-gold-400 font-semibold text-sm">رقم الطلب: REG-{regNum}</p>
        <button onClick={() => { setDone(false); setRole(null); setStep(1); }}
          className="btn-gold px-6 py-2.5 rounded-xl text-sm font-bold mt-5 w-full">تسجيل آخر</button>
      </div>
    </div>
  );

  return (
    <div className="space-y-5 page-in max-w-xl">
      <div className="glass rounded-2xl border border-gold-500/18 p-5 flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl btn-gold flex items-center justify-center animate-pulse-gold shrink-0"><Zap size={22} className="text-black" /></div>
        <div>
          <h2 className="text-white font-black text-xl">التسجيل السريع في خيط</h2>
          <p className="text-dk-400 text-sm mt-0.5">تسجيل فوري بالذكاء الاصطناعي</p>
        </div>
      </div>

      {/* Steps */}
      <div className="flex items-center gap-2">
        {[1,2,3].map(s => (
          <div key={s} className="flex items-center gap-2 flex-1">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm transition-all shrink-0 ${s < step ? 'bg-emerald-500 text-white' : s === step ? 'btn-gold text-black' : 'glass border border-gold-900/25 text-dk-500'}`}>
              {s < step ? <CheckCircle size={15} /> : s}
            </div>
            <span className={`text-xs hidden sm:block ${s === step ? 'text-gold-400 font-semibold' : 'text-dk-600'}`}>
              {s === 1 ? 'اختيار الدور' : s === 2 ? 'البيانات الأساسية' : 'التأكيد'}
            </span>
            {s < 3 && <div className={`flex-1 h-px ${s < step ? 'bg-emerald-500' : 'bg-dk-700'}`} />}
          </div>
        ))}
      </div>

      {/* Step 1 */}
      {step === 1 && (
        <div className="glass rounded-2xl border border-gold-900/15 p-5">
          <h3 className="text-white font-bold mb-4">اختر دورك في المنصة</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {ROLES.map(r => { const I = r.icon; return (
              <button key={r.id} onClick={() => setRole(r.id)}
                className={`p-5 rounded-xl border text-right transition-all ${role === r.id ? 'border-gold-500/35 bg-gold-500/8' : 'glass border-gold-900/15 hover:border-gold-900/35'}`}>
                <I size={22} className={`mb-3 ${role === r.id ? 'text-gold-400' : 'text-dk-500'}`} />
                <p className={`font-bold text-sm ${role === r.id ? 'text-white' : 'text-dk-200'}`}>{r.l}</p>
                <p className="text-dk-400 text-xs mt-1">{r.desc}</p>
              </button>
            ); })}
          </div>
          <button onClick={() => role && setStep(2)} disabled={!role}
            className="btn-gold px-6 py-2.5 rounded-xl text-sm font-bold mt-4 flex items-center gap-2 disabled:opacity-40">
            التالي <ChevronLeft size={15} />
          </button>
        </div>
      )}

      {/* Step 2 */}
      {step === 2 && (
        <div className="glass rounded-2xl border border-gold-900/15 p-5">
          <h3 className="text-white font-bold mb-4">البيانات الأساسية</h3>
          <div className="space-y-3">
            {[
              { icon: User, l: 'الاسم الكامل', p: 'أحمد محمد علي', t: 'text' },
              { icon: Phone, l: 'رقم الهاتف', p: '+218 91 xxxxxxx', t: 'tel' },
              { icon: Mail, l: 'البريد الإلكتروني', p: 'example@email.com', t: 'email' },
              { icon: MapPin, l: 'المنطقة في غات', p: 'غات - وسط المدينة', t: 'text' },
              ...(role === 'store' ? [{ icon: Building, l: 'اسم المتجر', p: 'محل النور', t: 'text' }] : []),
            ].map((f, i) => { const I = f.icon; return (
              <div key={i}>
                <label className="block text-dk-400 text-xs mb-1">{f.l}</label>
                <div className="flex items-center gap-2.5 glass rounded-xl px-3 py-2.5 border border-gold-900/15 focus-within:border-gold-500/35 transition-colors">
                  <I size={14} className="text-gold-500 shrink-0" />
                  <input type={f.t} placeholder={f.p} className="inp text-sm" />
                </div>
              </div>
            ); })}
          </div>
          <div className="flex gap-3 mt-4">
            <button onClick={() => setStep(1)} className="px-4 py-2.5 glass rounded-xl border border-gold-900/15 text-dk-300 hover:text-white text-sm">رجوع</button>
            <button onClick={() => setStep(3)} className="btn-gold px-6 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2">التالي <ChevronLeft size={15} /></button>
          </div>
        </div>
      )}

      {/* Step 3 */}
      {step === 3 && (
        <div className="glass rounded-2xl border border-gold-900/15 p-5">
          <h3 className="text-white font-bold mb-4">تأكيد التسجيل</h3>
          <div className="glass rounded-xl border border-gold-500/18 p-4 mb-4 space-y-2">
            {[
              ['الدور', ROLES.find(r => r.id === role)?.l ?? ''],
              ['نوع الحساب', 'حساب شخصي'],
              ['المنطقة', 'غات، ليبيا'],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between text-sm">
                <span className="text-dk-400">{k}</span>
                <span className="text-white font-semibold">{v}</span>
              </div>
            ))}
          </div>
          <p className="text-dk-500 text-xs mb-4 leading-relaxed">
            بالنقر على "تسجيل الآن" توافق على شروط الاستخدام وسياسة الخصوصية. سيتم التحقق تلقائياً خلال دقائق.
          </p>
          <div className="flex gap-3">
            <button onClick={() => setStep(2)} className="px-4 py-2.5 glass rounded-xl border border-gold-900/15 text-dk-300 hover:text-white text-sm">رجوع</button>
            <button onClick={() => setDone(true)} className="btn-gold px-6 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2">
              <Zap size={14} /> تسجيل الآن
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
