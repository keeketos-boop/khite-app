import { Truck, CheckCircle, Clock, AlertTriangle, MapPin, Package } from 'lucide-react';
import { ORDERS, DRIVERS } from '../data/seed';

const active = ORDERS.filter(o => o.status === 'in_transit' || o.status === 'accepted');
const STEPS = ['استلام', 'تأكيد', 'تجهيز', 'تسليم للسائق', 'في الطريق', 'تسليم'];

export default function Delivery() {
  return (
    <div className="space-y-5 page-in">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { l: 'جارية', v: active.length, icon: Truck, c: 'text-blue-400' },
          { l: 'مكتملة اليوم', v: 168, icon: CheckCircle, c: 'text-emerald-400' },
          { l: 'متوسط الوقت', v: '24 د', icon: Clock, c: 'text-gold-400' },
          { l: 'متأخرة', v: 2, icon: AlertTriangle, c: 'text-red-400' },
        ].map((s, i) => { const I = s.icon; return (
          <div key={i} className="card rounded-xl p-4"><I size={17} className={s.c + ' mb-2'} /><p className="text-white font-bold text-xl">{s.v}</p><p className="text-dk-400 text-xs mt-0.5">{s.l}</p></div>
        ); })}
      </div>

      <div className="glass rounded-2xl border border-gold-900/15 p-5">
        <h3 className="text-white font-bold mb-4">عمليات التوصيل الجارية</h3>
        <div className="space-y-4">
          {active.map(o => {
            const driver = DRIVERS.find(d => d.name === o.driver_name);
            const step = o.status === 'accepted' ? 3 : 4;
            return (
              <div key={o.id} className="glass rounded-xl border border-gold-900/15 p-4">
                <div className="flex flex-wrap gap-3 items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-gold-500/10 border border-gold-900/20 flex items-center justify-center shrink-0">
                      <Package size={17} className="text-gold-400" />
                    </div>
                    <div>
                      <p className="text-gold-400 font-mono font-bold text-sm">{o.id}</p>
                      <p className="text-white text-xs">{o.customer_name}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {driver && (
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-gradient-to-br from-gold-500 to-gold-700 flex items-center justify-center text-black font-bold text-xs shrink-0">
                          {driver.avatar_letter}
                        </div>
                        <p className="text-white text-xs font-semibold">{driver.name}</p>
                      </div>
                    )}
                    <span className="text-gold-300 font-bold">{o.total_amount} د.ل</span>
                  </div>
                </div>

                {/* Progress */}
                <div className="flex items-center gap-1 overflow-x-auto pb-1">
                  {STEPS.map((s, i) => (
                    <div key={i} className="flex items-center shrink-0">
                      <div className="flex flex-col items-center gap-0.5">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold border transition-all
                          ${i < step ? 'bg-emerald-500 border-emerald-500 text-white' : i === step ? 'btn-gold border-gold-500 animate-pulse-gold text-black' : 'glass border-gold-900/25 text-dk-500'}`}>
                          {i < step ? <CheckCircle size={11} /> : i + 1}
                        </div>
                        <span className={`text-[9px] whitespace-nowrap ${i <= step ? 'text-gold-400' : 'text-dk-600'}`}>{s}</span>
                      </div>
                      {i < STEPS.length - 1 && <div className={`w-5 h-px mx-0.5 mb-3 ${i < step ? 'bg-emerald-500' : 'bg-dk-700'}`} />}
                    </div>
                  ))}
                </div>

                <div className="flex items-center gap-4 mt-1 text-xs text-dk-400">
                  <span className="flex items-center gap-1"><MapPin size={11} className="text-gold-500" />{o.area}</span>
                  <span className="flex items-center gap-1"><Clock size={11} className="text-gold-500" />~18 دقيقة</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="glass rounded-2xl border border-gold-900/15 p-5">
        <h3 className="text-white font-bold mb-3">توافر السائقين</h3>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {DRIVERS.map(d => (
            <div key={d.id} className="glass rounded-xl border border-gold-900/15 p-3 text-center">
              <div className="relative inline-block mb-2">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gold-500 to-gold-700 flex items-center justify-center text-black font-bold">
                  {d.avatar_letter}
                </div>
                <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-dk-950 ${d.status === 'active' ? 'bg-emerald-400' : d.status === 'busy' ? 'bg-yellow-400' : 'bg-red-400'}`} />
              </div>
              <p className="text-white text-xs font-semibold">{d.name.split(' ')[0]}</p>
              <p className={`text-[10px] mt-0.5 ${d.status === 'active' ? 'text-emerald-400' : d.status === 'busy' ? 'text-yellow-400' : 'text-red-400'}`}>
                {d.status === 'active' ? 'متاح' : d.status === 'busy' ? 'مشغول' : 'غير متاح'}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
