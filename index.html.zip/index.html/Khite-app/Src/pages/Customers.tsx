import { useState } from 'react';
import { Users, Search, Plus, Phone, MapPin, ShoppingCart, Star, TrendingUp } from 'lucide-react';
import { CUSTOMERS } from '../data/seed';

export default function Customers() {
  const [search, setSearch] = useState('');
  const list = CUSTOMERS.filter(c => c.name.includes(search) || c.phone.includes(search));

  return (
    <div className="space-y-5 page-in">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { l: 'إجمالي العملاء', v: '1,247', icon: Users, c: 'text-gold-400' },
          { l: 'جدد هذا الشهر', v: '89', icon: TrendingUp, c: 'text-emerald-400' },
          { l: 'متوسط الإنفاق', v: '187 د.ل', icon: ShoppingCart, c: 'text-blue-400' },
          { l: 'معدل الرضا', v: '4.7/5', icon: Star, c: 'text-gold-400' },
        ].map((s, i) => { const I = s.icon; return (
          <div key={i} className="card rounded-xl p-4"><I size={17} className={s.c + ' mb-2'} /><p className="text-white font-bold text-lg">{s.v}</p><p className="text-dk-400 text-xs mt-0.5">{s.l}</p></div>
        ); })}
      </div>

      <div className="flex flex-wrap gap-3 items-center justify-between glass rounded-xl border border-gold-900/15 p-4">
        <div className="flex items-center gap-2 glass rounded-xl px-3 py-2 border border-gold-900/15 flex-1 max-w-xs">
          <Search size={13} className="text-dk-400 shrink-0" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="بحث في العملاء..." className="inp text-sm" />
        </div>
        <button className="btn-gold px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-1.5">
          <Plus size={13} /> إضافة عميل
        </button>
      </div>

      <div className="glass rounded-2xl border border-gold-900/15 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px]">
            <thead>
              <tr className="border-b border-gold-900/15">
                {['#','الاسم','الهاتف','المنطقة','الطلبات','الإنفاق','التقييم','تاريخ التسجيل'].map(h => (
                  <th key={h} className="text-right py-3 px-4 text-dk-400 text-xs font-semibold">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {list.map((c, i) => (
                <tr key={c.id} className="trow border-b border-gold-900/8 cursor-pointer">
                  <td className="py-3 px-4">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-gold-600/20 to-gold-800/20 border border-gold-900/20 flex items-center justify-center text-gold-400 font-bold text-xs">
                      {c.name[0]}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-white text-sm font-medium">{c.name}</td>
                  <td className="py-3 px-4"><div className="flex items-center gap-1"><Phone size={11} className="text-dk-500" /><span className="text-dk-300 text-xs">{c.phone}</span></div></td>
                  <td className="py-3 px-4"><div className="flex items-center gap-1"><MapPin size={11} className="text-dk-500" /><span className="text-dk-300 text-xs">{c.area}</span></div></td>
                  <td className="py-3 px-4 text-gold-300 font-bold text-sm">{c.total_orders}</td>
                  <td className="py-3 px-4 text-gold-400 font-bold text-sm">{c.total_spent.toLocaleString()} د.ل</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-1"><Star size={11} className="text-gold-400 fill-gold-400" /><span className="text-gold-400 text-xs font-bold">{c.rating}</span></div>
                  </td>
                  <td className="py-3 px-4 text-dk-400 text-xs">يناير 2025</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
