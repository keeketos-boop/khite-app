import { Star, Award, Zap, Shield, Package, Truck, Users, TrendingUp } from 'lucide-react';

const BADGES = [
  { name: 'شريك ذهبي', icon: Award, cls: 'text-gold-400', bg: 'from-gold-600/20 to-gold-900/10', desc: 'أكمل 100+ طلب', earned: true },
  { name: 'توصيل سريع', icon: Zap, cls: 'text-blue-400', bg: 'from-blue-600/20 to-blue-900/10', desc: 'متوسط أقل من 20 دقيقة', earned: true },
  { name: 'موثوق', icon: Shield, cls: 'text-emerald-400', bg: 'from-emerald-600/20 to-emerald-900/10', desc: 'تقييم 4.8+', earned: true },
  { name: 'خبير المخزون', icon: Package, cls: 'text-purple-400', bg: 'from-purple-600/20 to-purple-900/10', desc: 'إدارة 50+ منتج', earned: false },
  { name: 'قائد الفريق', icon: Users, cls: 'text-orange-400', bg: 'from-orange-600/20 to-orange-900/10', desc: 'إدارة 5+ سائقين', earned: true },
  { name: 'بطل التوصيل', icon: Truck, cls: 'text-red-400', bg: 'from-red-600/20 to-red-900/10', desc: '500+ طلب مكتمل', earned: false },
];

const REVIEWS = [
  { customer: 'أحمد محمد', score: 5, comment: 'خدمة ممتازة وتوصيل سريع جداً، شكراً لفريق خيط', time: 'اليوم', entity: 'السائق خالد سالم' },
  { customer: 'فاطمة الزهراء', score: 4, comment: 'الطلب وصل في الوقت المحدد، المنصة سهلة الاستخدام', time: 'أمس', entity: 'متجر النور' },
  { customer: 'مريم سالم', score: 5, comment: 'أفضل تطبيق توصيل في غات، أنصح به الجميع', time: 'منذ يومين', entity: 'المنصة' },
  { customer: 'عمر الشريف', score: 3, comment: 'التوصيل جيد لكن تأخر قليلاً عن الموعد', time: 'منذ 3 أيام', entity: 'السائق يوسف عبدالله' },
];

export default function Ratings() {
  return (
    <div className="space-y-5 page-in">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { l: 'متوسط التقييم', v: '4.7', suffix: '/5', icon: Star, c: 'text-gold-400' },
          { l: 'إجمالي التقييمات', v: '1,248', suffix: '', icon: TrendingUp, c: 'text-blue-400' },
          { l: 'شارات مكتسبة', v: '4', suffix: '/6', icon: Award, c: 'text-gold-400' },
          { l: 'نقاط الولاء', v: '2,840', suffix: '', icon: Zap, c: 'text-purple-400' },
        ].map((s, i) => { const I = s.icon; return (
          <div key={i} className="card rounded-xl p-4"><I size={17} className={s.c + ' mb-2'} /><p className="text-white font-bold text-xl">{s.v}<span className="text-sm text-dk-500">{s.suffix}</span></p><p className="text-dk-400 text-xs mt-0.5">{s.l}</p></div>
        ); })}
      </div>

      <div className="glass rounded-2xl border border-gold-900/15 p-5">
        <h3 className="text-white font-bold mb-4">توزيع التقييمات</h3>
        <div className="flex items-center gap-8 flex-wrap">
          <div className="text-center">
            <p className="text-5xl font-black gold-text">4.7</p>
            <div className="flex justify-center gap-0.5 mt-2">
              {[1,2,3,4,5].map(s => <Star key={s} size={15} className={s <= 4 ? 'text-gold-400 fill-gold-400' : 'text-gold-400'} />)}
            </div>
            <p className="text-dk-400 text-xs mt-1">1,248 تقييم</p>
          </div>
          <div className="flex-1 space-y-2 min-w-48">
            {[{s:5,n:820,p:66},{s:4,n:285,p:23},{s:3,n:98,p:8},{s:2,n:32,p:2.5},{s:1,n:13,p:1}].map(r => (
              <div key={r.s} className="flex items-center gap-2">
                <div className="flex items-center gap-0.5 w-10 shrink-0">
                  <span className="text-dk-400 text-xs">{r.s}</span>
                  <Star size={10} className="text-gold-400 fill-gold-400" />
                </div>
                <div className="flex-1 bg-dk-800 rounded-full h-1.5">
                  <div className="h-1.5 rounded-full prog-bar" style={{ width: `${r.p}%` }} />
                </div>
                <span className="text-dk-400 text-xs w-8">{r.n}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="glass rounded-2xl border border-gold-900/15 p-5">
        <h3 className="text-white font-bold mb-4">الشارات والإنجازات</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {BADGES.map((b, i) => { const I = b.icon; return (
            <div key={i} className={`glass rounded-xl border p-4 text-center transition-all ${b.earned ? 'border-gold-500/25 hover:border-gold-400/45' : 'border-gold-900/10 opacity-40'}`}>
              <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${b.bg} flex items-center justify-center mx-auto mb-2`}><I size={22} className={b.cls} /></div>
              <p className="text-white text-xs font-bold">{b.name}</p>
              <p className="text-dk-400 text-[10px] mt-0.5">{b.desc}</p>
              {b.earned && <span className="badge-ok px-1.5 py-0.5 rounded-full text-[9px] font-semibold mt-1.5 inline-block">مكتسبة</span>}
            </div>
          ); })}
        </div>
      </div>

      <div className="glass rounded-2xl border border-gold-900/15 p-5">
        <h3 className="text-white font-bold mb-4">آخر التقييمات</h3>
        <div className="space-y-3">
          {REVIEWS.map((r, i) => (
            <div key={i} className="glass rounded-xl border border-gold-900/15 p-4">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-gold-600/20 to-gold-800/20 border border-gold-900/20 flex items-center justify-center text-gold-400 font-bold text-xs shrink-0">{r.customer[0]}</div>
                  <div><p className="text-white text-xs font-semibold">{r.customer}</p><p className="text-dk-400 text-[10px]">{r.entity}</p></div>
                </div>
                <div className="flex gap-0.5">{[1,2,3,4,5].map(s => <Star key={s} size={11} className={s <= r.score ? 'text-gold-400 fill-gold-400' : 'text-dk-700'} />)}</div>
              </div>
              <p className="text-dk-300 text-xs leading-relaxed">{r.comment}</p>
              <p className="text-dk-600 text-[10px] mt-1.5">{r.time}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
