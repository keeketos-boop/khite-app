import { useState } from 'react';
import { User, Phone, MapPin, Mail, Edit, Shield, Star, Package, TrendingUp, Award, Check } from 'lucide-react';

export default function Profile() {
  const [editing, setEditing] = useState(false);
  const [saved, setSaved] = useState(false);

  const save = () => { setSaved(true); setEditing(false); setTimeout(() => setSaved(false), 2000); };

  return (
    <div className="space-y-5 page-in max-w-3xl">
      <div className="glass rounded-2xl border border-gold-500/18 p-6">
        <div className="flex items-start gap-5 flex-wrap">
          <div className="relative">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-gold-500 to-gold-700 flex items-center justify-center text-black font-black text-3xl shadow-[0_0_24px_rgba(245,158,11,0.4)]">م</div>
            <button className="absolute -bottom-1 -right-1 w-7 h-7 btn-gold rounded-lg flex items-center justify-center">
              <Edit size={13} className="text-black" />
            </button>
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="text-white font-black text-2xl">محمد الأمين</h2>
            <p className="text-gold-400 text-sm font-semibold mt-0.5">مدير المنصة الرئيسي</p>
            <div className="flex flex-wrap gap-2 mt-2">
              <span className="badge-ok px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1.5"><Shield size={11} /> مدير موثق</span>
              <span className="badge-warn px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1.5"><Award size={11} /> خبير المنصة</span>
            </div>
          </div>
          <button onClick={() => setEditing(!editing)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all ${editing ? 'glass border border-gold-900/15 text-dk-300' : 'btn-gold'}`}>
            <Edit size={14} />{editing ? 'إلغاء' : 'تعديل'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { l: 'طلبات مُدارة', v: '12,450', icon: Package, c: 'text-gold-400' },
          { l: 'إيرادات', v: '284K د.ل', icon: TrendingUp, c: 'text-emerald-400' },
          { l: 'تقييم الأداء', v: '4.9/5', icon: Star, c: 'text-gold-400' },
          { l: 'أيام في المنصة', v: '187', icon: Shield, c: 'text-blue-400' },
        ].map((s, i) => { const I = s.icon; return (
          <div key={i} className="card rounded-xl p-4"><I size={17} className={s.c + ' mb-2'} /><p className="text-white font-bold text-lg">{s.v}</p><p className="text-dk-400 text-xs mt-0.5">{s.l}</p></div>
        ); })}
      </div>

      <div className="glass rounded-2xl border border-gold-900/15 p-5">
        <h3 className="text-white font-bold mb-4">المعلومات الشخصية</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {[
            { icon: User, l: 'الاسم الكامل', v: 'محمد الأمين' },
            { icon: Phone, l: 'رقم الهاتف', v: '+218 91 1234567' },
            { icon: Mail, l: 'البريد الإلكتروني', v: 'm.alamin@khite.ly' },
            { icon: MapPin, l: 'المدينة', v: 'غات، ليبيا' },
          ].map((f, i) => {
            const I = f.icon;
            return (
              <div key={i} className="glass rounded-xl border border-gold-900/15 p-4 flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-gold-500/10 flex items-center justify-center shrink-0"><I size={15} className="text-gold-400" /></div>
                <div className="flex-1 min-w-0">
                  <p className="text-dk-400 text-xs">{f.l}</p>
                  {editing
                    ? <input defaultValue={f.v} className="mt-0.5 bg-transparent text-white text-sm border-b border-gold-500/35 outline-none w-full text-right" />
                    : <p className="text-white text-sm font-semibold mt-0.5">{f.v}</p>
                  }
                </div>
              </div>
            );
          })}
        </div>
        {editing && (
          <button onClick={save} className="mt-4 btn-gold px-5 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2">
            <Check size={15} /> حفظ التغييرات
          </button>
        )}
        {saved && <p className="mt-2 text-emerald-400 text-sm">تم حفظ التغييرات بنجاح ✓</p>}
      </div>

      <div className="glass rounded-2xl border border-gold-900/15 p-5">
        <h3 className="text-white font-bold mb-4">سجل النشاط الأخير</h3>
        <div className="space-y-2">
          {[
            { a: 'تسجيل دخول من جهاز جديد', t: 'اليوم 10:30 ص', c: 'bg-red-400' },
            { a: 'قبول طلب #ORD-004 يدوياً', t: 'اليوم 11:00 ص', c: 'bg-gold-400' },
            { a: 'تعديل إعدادات المنصة', t: 'أمس 3:15 م', c: 'bg-purple-400' },
            { a: 'إضافة سائق جديد: حسن العربي', t: 'أمس 5:40 م', c: 'bg-blue-400' },
            { a: 'تصدير تقرير شهري', t: 'قبل يومين', c: 'bg-emerald-400' },
          ].map((l, i) => (
            <div key={i} className="flex items-center gap-3 py-2 border-b border-gold-900/10">
              <div className={`w-2 h-2 rounded-full shrink-0 ${l.c}`} />
              <p className="text-dk-200 text-sm flex-1">{l.a}</p>
              <p className="text-dk-600 text-xs shrink-0">{l.t}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
