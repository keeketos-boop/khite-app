import { useState } from 'react';
import { Bell, ShoppingCart, Truck, CreditCard, Settings, Bot, CheckCheck, Trash2 } from 'lucide-react';
import { NOTIFICATIONS } from '../data/seed';
import type { Notification, NotifType } from '../types';

const TC: Record<NotifType, { icon: React.ComponentType<{size?:number;className?:string}>; cls: string; bg: string }> = {
  order:    { icon: ShoppingCart, cls: 'text-gold-400',    bg: 'bg-gold-500/10' },
  delivery: { icon: Truck,        cls: 'text-blue-400',    bg: 'bg-blue-500/10' },
  payment:  { icon: CreditCard,   cls: 'text-emerald-400', bg: 'bg-emerald-500/10' },
  system:   { icon: Settings,     cls: 'text-purple-400',  bg: 'bg-purple-500/10' },
  ai:       { icon: Bot,          cls: 'text-gold-400',    bg: 'bg-gold-500/10' },
};
const TL: Record<NotifType, string> = { order: 'طلب', delivery: 'توصيل', payment: 'دفع', system: 'نظام', ai: 'AI' };
const BadgeCls: Record<NotifType, string> = { order: 'badge-warn', delivery: 'badge-info', payment: 'badge-ok', system: 'badge-ai', ai: 'badge-warn' };

export default function Notifications() {
  const [notifs, setNotifs] = useState<Notification[]>(NOTIFICATIONS);
  const [filter, setFilter] = useState('all');

  const unread = notifs.filter(n => !n.is_read).length;
  const markAll = () => setNotifs(p => p.map(n => ({ ...n, is_read: true })));
  const clear = () => setNotifs([]);
  const read = (id: string) => setNotifs(p => p.map(n => n.id === id ? { ...n, is_read: true } : n));

  const list = filter === 'all' ? notifs : filter === 'unread' ? notifs.filter(n => !n.is_read) : notifs.filter(n => n.type === filter);

  return (
    <div className="space-y-5 page-in">
      <div className="flex flex-wrap items-center justify-between gap-3 glass rounded-xl border border-gold-900/15 p-4">
        <div className="flex items-center gap-3">
          <Bell size={19} className="text-gold-400" />
          <h3 className="text-white font-bold">الإشعارات</h3>
          {unread > 0 && <span className="w-6 h-6 rounded-full bg-red-500 text-white text-xs flex items-center justify-center font-bold">{unread}</span>}
        </div>
        <div className="flex gap-2">
          <button onClick={markAll} className="flex items-center gap-1.5 px-3 py-1.5 glass rounded-lg border border-gold-900/15 text-dk-300 hover:text-gold-400 text-xs transition-all"><CheckCheck size={12} /> قراءة الكل</button>
          <button onClick={clear} className="flex items-center gap-1.5 px-3 py-1.5 glass rounded-lg border border-red-900/20 text-red-400 hover:bg-red-500/10 text-xs transition-all"><Trash2 size={12} /> مسح</button>
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-0.5">
        {[{v:'all',l:'الكل'},{v:'unread',l:'غير مقروءة'},{v:'order',l:'طلبات'},{v:'delivery',l:'توصيل'},{v:'payment',l:'دفع'},{v:'system',l:'نظام'}].map(t => (
          <button key={t.v} onClick={() => setFilter(t.v)}
            className={`shrink-0 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${filter === t.v ? 'btn-gold' : 'glass border border-gold-900/15 text-dk-300 hover:text-gold-400'}`}>
            {t.l}
          </button>
        ))}
      </div>

      {list.length === 0 ? (
        <div className="glass rounded-2xl border border-gold-900/15 p-12 text-center">
          <Bell size={44} className="mx-auto mb-4 text-dk-700" />
          <p className="text-dk-400 text-sm">لا توجد إشعارات</p>
        </div>
      ) : (
        <div className="space-y-2">
          {list.map(n => {
            const tc = TC[n.type];
            const I = tc.icon;
            return (
              <div key={n.id} onClick={() => read(n.id)}
                className={`glass rounded-xl border transition-all cursor-pointer hover:border-gold-900/35 ${n.is_read ? 'border-gold-900/10' : 'border-gold-500/18'}`}>
                <div className="flex items-start gap-4 p-4">
                  <div className={`w-10 h-10 rounded-xl ${tc.bg} flex items-center justify-center shrink-0`}>
                    <I size={17} className={tc.cls} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm leading-relaxed ${n.is_read ? 'text-dk-300' : 'text-white font-medium'}`}>{n.message}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`${BadgeCls[n.type]} px-2 py-0.5 rounded-full text-[10px] font-semibold`}>{TL[n.type]}</span>
                      <span className="text-dk-600 text-[10px]">منذ دقائق</span>
                    </div>
                  </div>
                  {!n.is_read && <div className="w-2.5 h-2.5 rounded-full bg-gold-400 shrink-0 mt-1 animate-dot-pulse" />}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
