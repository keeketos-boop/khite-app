import { BarChart3, TrendingUp, Star, ShoppingCart, MapPin, Zap, CreditCard } from 'lucide-react';
import { CHART_WEEKLY, CHART_LABELS, CHART_REVENUE, STORES } from '../data/seed';

const maxW = Math.max(...CHART_WEEKLY);
const maxR = Math.max(...CHART_REVENUE);

const AREAS = [
  { name: 'غات - وسط المدينة', v: 87, pct: 85 },
  { name: 'غات - الشمالي', v: 64, pct: 63 },
  { name: 'غات - الجنوبية', v: 53, pct: 52 },
  { name: 'غات - الشرقية', v: 41, pct: 40 },
  { name: 'غات - الغربية', v: 27, pct: 26 },
];

export default function Analytics() {
  return (
    <div className="space-y-5 page-in">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { l: 'إيرادات الشهر', v: '48,200 د.ل', c: 'text-gold-400', icon: CreditCard },
          { l: 'معدل الإتمام', v: '94.2%', c: 'text-emerald-400', icon: TrendingUp },
          { l: 'متوسط الطلب', v: '87 د.ل', c: 'text-blue-400', icon: ShoppingCart },
          { l: 'رضا العملاء', v: '4.7/5', c: 'text-gold-400', icon: Star },
        ].map((s, i) => { const I = s.icon; return (
          <div key={i} className="card rounded-xl p-4"><I size={17} className={s.c + ' mb-2'} /><p className="text-white font-bold text-lg">{s.v}</p><p className="text-dk-400 text-xs mt-0.5">{s.l}</p></div>
        ); })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="glass rounded-2xl border border-gold-900/15 p-5">
          <div className="flex items-center justify-between mb-4">
            <div><h3 className="text-white font-bold">الطلبات الأسبوعية</h3><p className="text-dk-500 text-xs mt-0.5">آخر 7 أيام</p></div>
            <BarChart3 size={17} className="text-gold-400" />
          </div>
          <div className="flex items-end gap-2 h-36">
            {CHART_WEEKLY.map((v, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-1">
                <span className="text-gold-400 text-[10px] font-bold">{v}</span>
                <div className="w-full rounded-t-md prog-bar chart-bar" style={{ height: `${(v / maxW) * 110}px`, animationDelay: `${i * 0.08}s` }} />
                <span className="text-[9px] text-dk-500">{CHART_LABELS[i]}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="glass rounded-2xl border border-gold-900/15 p-5">
          <div className="flex items-center justify-between mb-4">
            <div><h3 className="text-white font-bold">الإيرادات الأسبوعية</h3><p className="text-dk-500 text-xs mt-0.5">بالدينار الليبي</p></div>
            <TrendingUp size={17} className="text-gold-400" />
          </div>
          <div className="flex items-end gap-2 h-36">
            {CHART_REVENUE.map((v, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-1">
                <span className="text-gold-400 text-[9px] font-bold">{v}</span>
                <div className="w-full rounded-t-md chart-bar" style={{ height: `${(v / maxR) * 110}px`, background: 'linear-gradient(to top,#d97706,#fbbf24)', animationDelay: `${i * 0.08}s` }} />
                <span className="text-[9px] text-dk-500">{CHART_LABELS[i]}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Top areas */}
        <div className="glass rounded-2xl border border-gold-900/15 p-5">
          <div className="flex items-center gap-2 mb-4"><MapPin size={16} className="text-gold-400" /><h3 className="text-white font-bold">أكثر المناطق طلباً</h3></div>
          <div className="space-y-3">
            {AREAS.map((a, i) => (
              <div key={i}>
                <div className="flex justify-between mb-1"><span className="text-dk-300 text-xs">{a.name}</span><span className="text-gold-400 text-xs font-bold">{a.v}</span></div>
                <div className="w-full bg-dk-800 rounded-full h-1.5">
                  <div className="h-1.5 rounded-full prog-bar" style={{ width: `${a.pct}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top stores */}
        <div className="glass rounded-2xl border border-gold-900/15 p-5">
          <div className="flex items-center gap-2 mb-4"><TrendingUp size={16} className="text-gold-400" /><h3 className="text-white font-bold">أعلى المتاجر أداءً</h3></div>
          <div className="space-y-2">
            {[...STORES].sort((a, b) => b.total_revenue - a.total_revenue).map((s, i) => (
              <div key={s.id} className="flex items-center gap-3 py-2 border-b border-gold-900/10">
                <div className="w-7 h-7 rounded-full bg-gradient-to-br from-gold-600 to-gold-800 flex items-center justify-center text-black font-bold text-xs shrink-0">{i + 1}</div>
                <div className="flex-1 min-w-0">
                  <p className="text-white text-sm font-semibold truncate">{s.name}</p>
                  <p className="text-dk-400 text-[10px]">{s.total_orders} طلب</p>
                </div>
                <p className="text-gold-400 text-sm font-bold shrink-0">{s.total_revenue.toLocaleString()} د.ل</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* AI Insights */}
      <div className="glass rounded-2xl border border-gold-500/15 p-5">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-9 h-9 rounded-xl btn-gold flex items-center justify-center shrink-0"><Zap size={16} className="text-black" /></div>
          <div><h3 className="text-white font-bold">رؤى الذكاء الاصطناعي</h3><p className="text-dk-400 text-xs">تحليلات لتحسين الأداء</p></div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[
            { t: 'ذروة الطلبات', d: 'أعلى معدل بين 11 صباحاً - 1 ظهراً. يُنصح بسائقين إضافيين في هذا الوقت.' },
            { t: 'توقع الطلب', d: 'الذكاء الاصطناعي يتوقع زيادة 35% يوم الجمعة القادم بناءً على البيانات التاريخية.' },
            { t: 'تحسين المسار', d: 'إمكانية توفير 18% من وقت التوصيل بإعادة توزيع السائقين جغرافياً.' },
          ].map((ins, i) => (
            <div key={i} className="glass rounded-xl border border-gold-900/15 p-4">
              <h4 className="text-gold-400 text-sm font-bold mb-2">{ins.t}</h4>
              <p className="text-dk-300 text-xs leading-relaxed">{ins.d}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
