import { CreditCard, Banknote, Smartphone, TrendingUp, Download, Filter, CheckCircle, Clock, XCircle } from 'lucide-react';

const TXN = [
  { id: 'TXN-001', customer: 'أحمد محمد', amount: 85, method: 'cash', status: 'completed', order: 'ORD-001', time: '10:32 ص' },
  { id: 'TXN-002', customer: 'فاطمة الزهراء', amount: 230, method: 'card', status: 'pending', order: 'ORD-002', time: '10:45 ص' },
  { id: 'TXN-003', customer: 'عمر الشريف', amount: 45, method: 'prepaid', status: 'completed', order: 'ORD-003', time: '09:15 ص' },
  { id: 'TXN-004', customer: 'مريم سالم', amount: 160, method: 'cash', status: 'completed', order: 'ORD-004', time: '11:00 ص' },
  { id: 'TXN-005', customer: 'إبراهيم الكوني', amount: 30, method: 'cash', status: 'failed', order: 'ORD-005', time: '09:50 ص' },
  { id: 'TXN-006', customer: 'سارة الأمين', amount: 120, method: 'card', status: 'completed', order: 'ORD-006', time: '11:20 ص' },
  { id: 'TXN-007', customer: 'عبدالرحمن فرج', amount: 350, method: 'prepaid', status: 'pending', order: 'ORD-007', time: '11:35 ص' },
];

const ML = { cash: 'دفع عند الاستلام', card: 'بطاقة بنكية', prepaid: 'بطاقة مسبقة' } as Record<string,string>;
const MI = { cash: Banknote, card: CreditCard, prepaid: Smartphone } as Record<string,React.ComponentType<{size?:number;className?:string}>>;

const SB = ({ s }: { s: string }) =>
  s === 'completed' ? <span className="badge-ok px-2 py-0.5 rounded-full text-[10px] font-semibold flex items-center gap-1 w-fit"><CheckCircle size={9} />مكتمل</span> :
  s === 'pending'   ? <span className="badge-warn px-2 py-0.5 rounded-full text-[10px] font-semibold flex items-center gap-1 w-fit"><Clock size={9} />معلق</span> :
                      <span className="badge-err px-2 py-0.5 rounded-full text-[10px] font-semibold flex items-center gap-1 w-fit"><XCircle size={9} />فشل</span>;

export default function Payments() {
  const done = TXN.filter(t => t.status === 'completed');
  const total    = done.reduce((s, t) => s + t.amount, 0);
  const cash     = done.filter(t => t.method === 'cash').reduce((s, t) => s + t.amount, 0);
  const card     = done.filter(t => t.method === 'card').reduce((s, t) => s + t.amount, 0);
  const prepaid  = done.filter(t => t.method === 'prepaid').reduce((s, t) => s + t.amount, 0);

  return (
    <div className="space-y-5 page-in">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { l: 'إجمالي المحصّل', v: `${total} د.ل`, icon: TrendingUp, c: 'text-gold-400' },
          { l: 'دفع عند الاستلام', v: `${cash} د.ل`, icon: Banknote, c: 'text-emerald-400' },
          { l: 'بطاقة بنكية', v: `${card} د.ل`, icon: CreditCard, c: 'text-blue-400' },
          { l: 'بطاقة مسبقة', v: `${prepaid} د.ل`, icon: Smartphone, c: 'text-purple-400' },
        ].map((s, i) => { const I = s.icon; return (
          <div key={i} className="card rounded-xl p-4"><I size={17} className={s.c + ' mb-2'} /><p className="text-white font-bold text-lg">{s.v}</p><p className="text-dk-400 text-xs mt-0.5">{s.l}</p></div>
        ); })}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          { l: 'دفع عند الاستلام', v: cash, pct: Math.round((cash / total) * 100), color: '#10b981' },
          { l: 'بطاقة بنكية', v: card, pct: Math.round((card / total) * 100), color: '#3b82f6' },
          { l: 'بطاقة مسبقة', v: prepaid, pct: Math.round((prepaid / total) * 100), color: '#8b5cf6' },
        ].map((m, i) => (
          <div key={i} className="glass rounded-xl border border-gold-900/15 p-4">
            <div className="flex justify-between mb-2"><span className="text-dk-300 text-sm">{m.l}</span><span className="text-white font-bold">{m.pct}%</span></div>
            <div className="w-full bg-dk-800 rounded-full h-2 mb-2">
              <div className="h-2 rounded-full" style={{ width: `${m.pct}%`, background: m.color, boxShadow: `0 0 8px ${m.color}55` }} />
            </div>
            <p className="text-gold-400 font-bold">{m.v} د.ل</p>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap gap-3 items-center justify-between glass rounded-xl border border-gold-900/15 p-4">
        <h3 className="text-white font-bold">سجل المعاملات</h3>
        <div className="flex gap-2">
          <button className="flex items-center gap-1.5 px-3 py-2 glass rounded-xl border border-gold-900/15 text-dk-300 hover:text-gold-400 text-sm"><Filter size={13} /> فلتر</button>
          <button className="flex items-center gap-1.5 px-3 py-2 glass rounded-xl border border-gold-900/15 text-dk-300 hover:text-gold-400 text-sm"><Download size={13} /> تصدير</button>
        </div>
      </div>

      <div className="glass rounded-2xl border border-gold-900/15 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[580px]">
            <thead>
              <tr className="border-b border-gold-900/15">
                {['رقم المعاملة','العميل','المبلغ','طريقة الدفع','الطلب','الوقت','الحالة'].map(h => (
                  <th key={h} className="text-right py-3 px-4 text-dk-400 text-xs font-semibold">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {TXN.map(t => { const MI2 = MI[t.method]; return (
                <tr key={t.id} className="trow border-b border-gold-900/8">
                  <td className="py-3 px-4 text-gold-400 font-mono font-bold text-xs">{t.id}</td>
                  <td className="py-3 px-4 text-white text-sm">{t.customer}</td>
                  <td className="py-3 px-4 text-gold-300 font-bold text-sm">{t.amount} د.ل</td>
                  <td className="py-3 px-4"><div className="flex items-center gap-1.5"><MI2 size={12} className="text-dk-400" /><span className="text-dk-300 text-xs">{ML[t.method]}</span></div></td>
                  <td className="py-3 px-4 text-dk-400 font-mono text-xs">{t.order}</td>
                  <td className="py-3 px-4 text-dk-400 text-xs">{t.time}</td>
                  <td className="py-3 px-4"><SB s={t.status} /></td>
                </tr>
              ); })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
