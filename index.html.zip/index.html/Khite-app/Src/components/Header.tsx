import { Menu, Bell, Search, Zap, Wifi, ChevronDown } from 'lucide-react';
import type { Page } from '../types';

const TITLES: Record<Page, string> = {
  dashboard: 'لوحة التحكم', orders: 'إدارة الطلبات', delivery: 'إدارة التوصيل',
  tracking: 'تتبع GPS مباشر', inventory: 'إدارة المخزون', analytics: 'التحليلات الذكية',
  payments: 'إدارة المدفوعات', stores: 'المتاجر', drivers: 'السائقون',
  customers: 'العملاء', referrals: 'روابط الإحالة', ratings: 'التقييمات والشارات',
  'ai-assistant': 'مساعد الذكاء الاصطناعي', notifications: 'الإشعارات',
  settings: 'الإعدادات', profile: 'الملف الشخصي', register: 'التسجيل السريع',
};

interface Props {
  page: Page;
  onMenu: () => void;
  unread: number;
  onNav: (p: Page) => void;
}

export default function Header({ page, onMenu, unread, onNav }: Props) {
  return (
    <header className="sticky top-0 z-30 glass-dark px-4 py-3 lg:px-6">
      <div className="flex items-center gap-3">

        <button onClick={onMenu} className="lg:hidden w-9 h-9 glass rounded-xl border border-gold-900/20 flex items-center justify-center text-gold-400 shrink-0">
          <Menu size={18} />
        </button>

        {/* Mobile logo */}
        <div className="lg:hidden flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg btn-gold flex items-center justify-center">
            <Zap size={15} className="text-black" />
          </div>
          <span className="text-gold-400 font-black text-lg">خيط</span>
        </div>

        {/* Desktop title */}
        <div className="hidden lg:block">
          <h2 className="text-white font-bold text-base leading-none">{TITLES[page]}</h2>
          <p className="text-dk-400 text-xs mt-0.5">منصة خيط للتوصيل - غات، ليبيا</p>
        </div>

        {/* Search */}
        <div className="hidden md:flex flex-1 max-w-xs items-center gap-2 glass rounded-xl px-3 py-2 border border-gold-900/15 mx-4">
          <Search size={13} className="text-dk-400 shrink-0" />
          <input placeholder="بحث..." className="inp text-sm" />
        </div>

        <div className="flex-1" />

        <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 glass rounded-lg border border-emerald-500/20">
          <Wifi size={12} className="text-emerald-400" />
          <span className="text-[11px] text-emerald-400 font-medium">متصل</span>
        </div>

        <button onClick={() => onNav('notifications')}
          className="relative w-9 h-9 glass rounded-xl border border-gold-900/20 flex items-center justify-center text-dk-300 hover:text-gold-400 transition-colors">
          <Bell size={16} />
          {unread > 0 && (
            <span className="absolute -top-1 -left-1 w-4 h-4 rounded-full bg-red-500 text-white text-[9px] flex items-center justify-center font-bold animate-dot-pulse">
              {unread}
            </span>
          )}
        </button>

        <button onClick={() => onNav('profile')}
          className="flex items-center gap-2 px-2 py-1.5 glass rounded-xl border border-gold-900/15 hover:border-gold-600/35 transition-all">
          <div className="w-7 h-7 rounded-full bg-gradient-to-br from-gold-500 to-gold-700 flex items-center justify-center text-black font-bold text-xs">م</div>
          <ChevronDown size={12} className="text-dk-400 hidden sm:block" />
        </button>

      </div>
    </header>
  );
}
