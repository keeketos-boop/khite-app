import { useState } from 'react';
import {
  LayoutDashboard, ShoppingCart, Truck, MapPin, Package, BarChart3,
  CreditCard, Store, Users, UserCheck, Share2, Star, Bot, Bell,
  Settings, User, ChevronDown, ChevronUp, X, LogOut, Zap, Globe, Shield
} from 'lucide-react';
import type { Page } from '../types';

interface Props {
  page: Page;
  onNav: (p: Page) => void;
  open: boolean;
  onClose: () => void;
  unread: number;
}

const GROUPS = [
  { title: 'الرئيسية', items: [
    { id: 'dashboard' as Page, label: 'لوحة التحكم', icon: LayoutDashboard },
  ]},
  { title: 'إدارة الطلبات', items: [
    { id: 'orders' as Page, label: 'الطلبات', icon: ShoppingCart },
    { id: 'delivery' as Page, label: 'التوصيل', icon: Truck },
    { id: 'tracking' as Page, label: 'تتبع GPS مباشر', icon: MapPin },
  ]},
  { title: 'إدارة المتاجر', items: [
    { id: 'stores' as Page, label: 'المتاجر', icon: Store },
    { id: 'inventory' as Page, label: 'المخزون', icon: Package },
    { id: 'drivers' as Page, label: 'السائقون', icon: UserCheck },
    { id: 'customers' as Page, label: 'العملاء', icon: Users },
  ]},
  { title: 'المالية والتحليل', items: [
    { id: 'analytics' as Page, label: 'التحليلات الذكية', icon: BarChart3 },
    { id: 'payments' as Page, label: 'المدفوعات', icon: CreditCard },
    { id: 'referrals' as Page, label: 'روابط الإحالة', icon: Share2 },
  ]},
  { title: 'المجتمع والذكاء', items: [
    { id: 'ratings' as Page, label: 'التقييمات والشارات', icon: Star },
    { id: 'ai-assistant' as Page, label: 'مساعد الذكاء الاصطناعي', icon: Bot },
    { id: 'notifications' as Page, label: 'الإشعارات', icon: Bell },
  ]},
  { title: 'الإعدادات', items: [
    { id: 'profile' as Page, label: 'الملف الشخصي', icon: User },
    { id: 'settings' as Page, label: 'الإعدادات', icon: Settings },
    { id: 'register' as Page, label: 'تسجيل جديد', icon: Zap },
  ]},
];

export default function Sidebar({ page, onNav, open, onClose, unread }: Props) {
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());

  const toggle = (t: string) => setCollapsed(prev => {
    const s = new Set(prev);
    s.has(t) ? s.delete(t) : s.add(t);
    return s;
  });

  const go = (p: Page) => { onNav(p); onClose(); };

  return (
    <>
      {open && <div className="fixed inset-0 z-40 overlay lg:hidden" onClick={onClose} />}
      <aside className={`
        fixed top-0 right-0 h-full z-50 w-[272px] glass-sidebar flex flex-col
        border-l border-gold-900/20 transition-transform duration-300
        ${open ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'}
      `}>

        {/* Logo */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gold-900/20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl btn-gold flex items-center justify-center animate-pulse-gold shrink-0">
              <Zap size={20} className="text-black" />
            </div>
            <div>
              <p className="text-lg font-black text-gold-400 leading-none">خيط</p>
              <p className="text-[10px] text-dk-400 mt-0.5">منصة التوصيل الذكية</p>
            </div>
          </div>
          <button onClick={onClose} className="lg:hidden w-8 h-8 glass rounded-lg flex items-center justify-center text-gold-400">
            <X size={15} />
          </button>
        </div>

        {/* Admin card */}
        <div className="mx-3 mt-3 px-3 py-2.5 glass rounded-xl border border-gold-900/20">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-gold-500 to-gold-700 flex items-center justify-center text-black font-bold text-sm shrink-0">م</div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white truncate">محمد الأمين</p>
              <p className="text-xs text-gold-500">مدير المنصة</p>
            </div>
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-dot-pulse shrink-0" />
          </div>
        </div>

        {/* Mini stats */}
        <div className="grid grid-cols-3 gap-2 px-3 mt-2.5">
          {[['247','طلب'],['12','سائق'],['38','متجر']].map(([v, l]) => (
            <div key={l} className="glass rounded-lg py-2 text-center border border-gold-900/15">
              <p className="text-gold-400 font-bold text-sm">{v}</p>
              <p className="text-dk-400 text-[10px]">{l}</p>
            </div>
          ))}
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto px-3 mt-3 pb-4 space-y-0.5">
          {GROUPS.map(g => (
            <div key={g.title}>
              <button onClick={() => toggle(g.title)} className="w-full flex items-center justify-between px-2 py-1.5 text-[11px] text-dk-500 hover:text-gold-500 transition-colors font-semibold tracking-wide mb-0.5">
                {g.title}
                {collapsed.has(g.title) ? <ChevronDown size={11} /> : <ChevronUp size={11} />}
              </button>

              {!collapsed.has(g.title) && g.items.map(item => {
                const Icon = item.icon;
                const active = page === item.id;
                return (
                  <button key={item.id} onClick={() => go(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl mb-0.5 text-sm transition-all group
                      ${active ? 'nav-active font-semibold' : 'text-dk-300 hover:text-white hover:bg-white/[0.04]'}`}>
                    <Icon size={16} className={`shrink-0 ${active ? 'text-gold-400' : 'text-dk-500 group-hover:text-gold-500'} transition-colors`} />
                    <span className="flex-1 text-right">{item.label}</span>
                    {item.id === 'notifications' && unread > 0 && (
                      <span className="w-5 h-5 rounded-full bg-red-500 text-white text-[9px] flex items-center justify-center font-bold shrink-0">{unread}</span>
                    )}
                    {item.id === 'ai-assistant' && (
                      <span className="badge-ai text-[9px] px-1.5 py-0.5 rounded-full font-bold shrink-0">AI</span>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </nav>

        {/* Footer */}
        <div className="px-3 pb-4 space-y-2 border-t border-gold-900/15 pt-3">
          <div className="flex items-center gap-2 px-3 py-2 glass rounded-lg border border-gold-900/15">
            <Globe size={13} className="text-gold-500" />
            <span className="text-xs text-dk-300 flex-1">غات، ليبيا</span>
            <Shield size={13} className="text-emerald-500" />
          </div>
          <button className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-dk-400 hover:text-red-400 hover:bg-red-500/10 transition-all text-sm">
            <LogOut size={15} />
            <span>تسجيل الخروج</span>
          </button>
        </div>
      </aside>
    </>
  );
}
