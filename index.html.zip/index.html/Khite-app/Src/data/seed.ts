import type { Store, Driver, Customer, Order, Notification, InventoryItem } from '../types';

export const STORES: Store[] = [
  { id: 's1', name: 'متجر النور', owner_name: 'محمود البشير', phone: '+218911001001', area: 'غات - الشمالي', category: 'بقالة وتموين', status: 'active', rating: 4.8, total_orders: 245, total_revenue: 8750 },
  { id: 's2', name: 'سوق الأمل', owner_name: 'عائشة الصادق', phone: '+218912002002', area: 'غات - المركز', category: 'ملابس وأزياء', status: 'active', rating: 4.7, total_orders: 189, total_revenue: 12400 },
  { id: 's3', name: 'متجر البركة', owner_name: 'طارق الهادي', phone: '+218913003003', area: 'غات - الجنوبية', category: 'إلكترونيات', status: 'active', rating: 4.9, total_orders: 98, total_revenue: 22800 },
  { id: 's4', name: 'محل الفرح', owner_name: 'نورة الخليفي', phone: '+218914004004', area: 'غات - الشرقية', category: 'حلويات ومشروبات', status: 'active', rating: 4.6, total_orders: 312, total_revenue: 6200 },
  { id: 's5', name: 'متجر الواحة', owner_name: 'سليمان الأمين', phone: '+218915005005', area: 'غات - الغربية', category: 'مستلزمات منزلية', status: 'inactive', rating: 4.5, total_orders: 156, total_revenue: 9100 },
];

export const DRIVERS: Driver[] = [
  { id: 'd1', name: 'خالد سالم', phone: '+218921001001', area: 'غات - الشمالية', status: 'busy', rating: 4.8, total_orders: 47, avatar_letter: 'خ' },
  { id: 'd2', name: 'يوسف عبدالله', phone: '+218922002002', area: 'غات - الجنوبية', status: 'active', rating: 4.9, total_orders: 63, avatar_letter: 'ي' },
  { id: 'd3', name: 'محمد الطيب', phone: '+218923003003', area: 'غات - المركز', status: 'busy', rating: 4.7, total_orders: 38, avatar_letter: 'م' },
  { id: 'd4', name: 'علي الفاخري', phone: '+218924004004', area: 'غات - الشرقية', status: 'offline', rating: 4.5, total_orders: 25, avatar_letter: 'ع' },
  { id: 'd5', name: 'حسن العربي', phone: '+218925005005', area: 'غات - الغربية', status: 'active', rating: 4.6, total_orders: 52, avatar_letter: 'ح' },
];

export const CUSTOMERS: Customer[] = [
  { id: 'c1', name: 'أحمد محمد علي', phone: '+218911111111', area: 'غات - الشمالي', total_orders: 23, total_spent: 1850, rating: 4.8 },
  { id: 'c2', name: 'فاطمة الزهراء', phone: '+218922222222', area: 'غات - المركز', total_orders: 17, total_spent: 2400, rating: 4.9 },
  { id: 'c3', name: 'عمر الشريف', phone: '+218933333333', area: 'غات - الجنوبية', total_orders: 8, total_spent: 640, rating: 4.5 },
  { id: 'c4', name: 'مريم سالم', phone: '+218944444444', area: 'غات - الشرقية', total_orders: 31, total_spent: 3200, rating: 5.0 },
  { id: 'c5', name: 'إبراهيم الكوني', phone: '+218955555555', area: 'غات - الغربية', total_orders: 5, total_spent: 320, rating: 4.3 },
  { id: 'c6', name: 'سارة الأمين', phone: '+218966666666', area: 'غات - المركز', total_orders: 19, total_spent: 1760, rating: 4.7 },
];

export const ORDERS: Order[] = [
  { id: 'ORD-001', customer_name: 'أحمد محمد علي', store_name: 'متجر النور', driver_name: 'خالد سالم', area: 'غات - الشمالي', total_amount: 85, item_count: 3, status: 'in_transit', payment_method: 'cash', created_at: '2025-07-09T10:32:00Z' },
  { id: 'ORD-002', customer_name: 'فاطمة الزهراء', store_name: 'سوق الأمل', area: 'غات - المركز', total_amount: 230, item_count: 7, status: 'pending', payment_method: 'card', created_at: '2025-07-09T10:45:00Z' },
  { id: 'ORD-003', customer_name: 'عمر الشريف', store_name: 'متجر البركة', driver_name: 'يوسف عبدالله', area: 'غات - الجنوبية', total_amount: 45, item_count: 2, status: 'delivered', payment_method: 'prepaid', created_at: '2025-07-09T09:15:00Z' },
  { id: 'ORD-004', customer_name: 'مريم سالم', store_name: 'محل الفرح', driver_name: 'محمد الطيب', area: 'غات - الشرقية', total_amount: 160, item_count: 5, status: 'accepted', payment_method: 'cash', created_at: '2025-07-09T11:00:00Z' },
  { id: 'ORD-005', customer_name: 'إبراهيم الكوني', store_name: 'متجر الواحة', area: 'غات - الغربية', total_amount: 30, item_count: 1, status: 'cancelled', payment_method: 'cash', created_at: '2025-07-09T09:50:00Z' },
  { id: 'ORD-006', customer_name: 'سارة الأمين', store_name: 'سوق الخير', driver_name: 'خالد سالم', area: 'غات - المركز', total_amount: 120, item_count: 4, status: 'in_transit', payment_method: 'card', created_at: '2025-07-09T11:20:00Z' },
  { id: 'ORD-007', customer_name: 'عبدالرحمن فرج', store_name: 'متجر النجوم', area: 'غات - الحي الجديد', total_amount: 350, item_count: 8, status: 'pending', payment_method: 'prepaid', created_at: '2025-07-09T11:35:00Z' },
];

export const NOTIFICATIONS: Notification[] = [
  { id: 'n1', type: 'order', message: 'طلب جديد #ORD-007 من عبدالرحمن فرج بقيمة 350 د.ل', is_read: false, created_at: '2025-07-09T11:35:00Z' },
  { id: 'n2', type: 'delivery', message: 'الطلب #ORD-001 في الطريق - السائق خالد سالم', is_read: false, created_at: '2025-07-09T11:30:00Z' },
  { id: 'n3', type: 'ai', message: 'الذكاء الاصطناعي: تم تسجيل متجر جديد تلقائياً - سوق الخير', is_read: false, created_at: '2025-07-09T11:18:00Z' },
  { id: 'n4', type: 'payment', message: 'تم استلام دفعة بطاقة بنكية 230 د.ل - طلب #ORD-002', is_read: true, created_at: '2025-07-09T11:10:00Z' },
  { id: 'n5', type: 'system', message: 'تحديث المنصة v2.4.1 تم تطبيقه بنجاح', is_read: true, created_at: '2025-07-09T10:00:00Z' },
];

export const INVENTORY: InventoryItem[] = [
  { id: 'i1', name: 'زيت نباتي 2 لتر', category: 'تموين', stock: 145, threshold: 20, price: 12 },
  { id: 'i2', name: 'أرز بسمتي 5 كغ', category: 'تموين', stock: 8, threshold: 15, price: 28 },
  { id: 'i3', name: 'سكر أبيض 1 كغ', category: 'تموين', stock: 0, threshold: 10, price: 5 },
  { id: 'i4', name: 'مياه معدنية 1.5 لتر', category: 'مشروبات', stock: 420, threshold: 50, price: 2 },
  { id: 'i5', name: 'عصير برتقال 1 لتر', category: 'مشروبات', stock: 12, threshold: 20, price: 8 },
  { id: 'i6', name: 'حليب طازج 1 لتر', category: 'ألبان', stock: 85, threshold: 30, price: 6 },
];

export const CHART_WEEKLY = [65, 88, 72, 95, 82, 110, 98];
export const CHART_LABELS = ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];
export const CHART_REVENUE = [1200, 1850, 1600, 2100, 1900, 2400, 2200];
