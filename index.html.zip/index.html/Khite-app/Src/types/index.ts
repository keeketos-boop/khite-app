export type Page =
  | 'dashboard' | 'orders' | 'delivery' | 'tracking'
  | 'inventory' | 'analytics' | 'payments' | 'stores'
  | 'drivers' | 'customers' | 'referrals' | 'ratings'
  | 'ai-assistant' | 'notifications' | 'settings' | 'profile' | 'register';

export type OrderStatus = 'pending' | 'accepted' | 'in_transit' | 'delivered' | 'cancelled';
export type DriverStatus = 'active' | 'busy' | 'offline';
export type PaymentMethod = 'cash' | 'card' | 'prepaid';
export type NotifType = 'order' | 'delivery' | 'payment' | 'system' | 'ai';

export interface Store {
  id: string; name: string; owner_name: string; phone: string;
  area: string; category: string; status: 'active' | 'inactive';
  rating: number; total_orders: number; total_revenue: number;
}
export interface Driver {
  id: string; name: string; phone: string; area: string;
  status: DriverStatus; rating: number; total_orders: number; avatar_letter: string;
}
export interface Customer {
  id: string; name: string; phone: string; area: string;
  total_orders: number; total_spent: number; rating: number;
}
export interface Order {
  id: string; customer_name: string; store_name: string;
  driver_name?: string; area: string; total_amount: number;
  item_count: number; status: OrderStatus; payment_method: PaymentMethod;
  created_at: string;
}
export interface Notification {
  id: string; type: NotifType; message: string; is_read: boolean; created_at: string;
}
export interface InventoryItem {
  id: string; name: string; category: string;
  stock: number; threshold: number; price: number;
}
